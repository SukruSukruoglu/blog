
/**
 * Ana uygulama bileşeni - Tüm rota yapılandırmasını içerir
 */
import { HashRouter, Route, Routes } from 'react-router'
import Home from './pages/Home'
import Blog from './pages/Blog'
import BlogDetail from './pages/BlogDetail'
import Photos from './pages/Photos'
import Books from './pages/Books'
import About from './pages/About'
import Navbar from './components/Navbar'
import Admin from './pages/Admin'

export default function App() {
  return (
    <HashRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:id" element={<BlogDetail />} />
        <Route path="/fotograflar" element={<Photos />} />
        <Route path="/kitaplar" element={<Books />} />
        <Route path="/hakkimda" element={<About />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </HashRouter>
  )
}
