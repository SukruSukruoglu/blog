/**
 * Project Adakale store - Project verilerini yönetmek için zustand store
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface ProjectItem {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  isPublished: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
}

interface ProjectState {
  projects: ProjectItem[];
  addProject: (project: Omit<ProjectItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateProject: (id: number, updates: Partial<ProjectItem>) => void;
  deleteProject: (id: number) => void;
  reorderProjects: (projects: ProjectItem[]) => void;
  getPublishedProjects: () => ProjectItem[];
}

export const useProjectStore = create<ProjectState>()(
  persist(
    (set, get) => ({
      projects: [
        {
          id: 1,
          title: 'Adakale Tarihi',
          description: 'Adakale\'nin zengin tarihsel geçmişi ve önemli olayları hakkında detaylı bilgiler.',
          imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/6ea06755-5265-4ed9-b027-4c400a341986.jpg',
          isPublished: true,
          order: 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 2,
          title: 'Kültürel Miras',
          description: 'Adakale\'nin kültürel zenginlikleri, gelenekleri ve yerel yaşam biçimi.',
          imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/5e7bbc30-de14-4cfc-be76-5883205a4166.jpg',
          isPublished: true,
          order: 2,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 3,
          title: 'Doğal Güzellikler',
          description: 'Adakale\'nin eşsiz doğal manzaraları ve turistik değerleri.',
          imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/9381e427-0128-4fe9-b4a7-625bada1126e.jpg',
          isPublished: true,
          order: 3,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ],

      addProject: (projectData) => {
        const state = get();
        const newProject: ProjectItem = {
          ...projectData,
          id: Math.max(...state.projects.map(p => p.id), 0) + 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        set({ projects: [...state.projects, newProject] });
      },

      updateProject: (id, updates) => {
        const state = get();
        const updatedProjects = state.projects.map(project =>
          project.id === id
            ? { ...project, ...updates, updatedAt: new Date().toISOString() }
            : project
        );
        set({ projects: updatedProjects });
      },

      deleteProject: (id) => {
        const state = get();
        const filteredProjects = state.projects.filter(project => project.id !== id);
        set({ projects: filteredProjects });
      },

      reorderProjects: (projects) => {
        set({ projects });
      },

      getPublishedProjects: () => {
        const state = get();
        return state.projects
          .filter(project => project.isPublished)
          .sort((a, b) => a.order - b.order);
      }
    }),
    {
      name: 'project-adakale-store'
    }
  )
);
