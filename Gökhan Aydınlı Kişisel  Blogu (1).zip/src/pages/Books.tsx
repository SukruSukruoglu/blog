
/**
 * Kitaplar sayfası bileşeni - Kullanıcının kitap incelemelerini gösterir
 */
import { FC, useState } from 'react';
import { Search, BookOpen, Star, Filter, BookMarked, MessageCircle } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';

// Kitap verisi için arayüz
interface Book {
  id: number;
  title: string;
  author: string;
  coverImage: string;
  rating: number;
  review: string;
  genre: string;
  readDate: string;
}

const Books: FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  // Örnek kitap türleri
  const genres = ['Roman', 'Bilim Kurgu', 'Tarih', 'Felsefe', 'Kişisel Gelişim', 'Biyografi'];

  // Örnek kitap verileri
  const books: Book[] = [
    {
      id: 1,
      title: 'Tutunamayanlar',
      author: 'Oğuz Atay',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/1d1d3721-02ce-4a61-bf42-2cf22ff858b2.jpg',
      rating: 5,
      review: 'Türk edebiyatının başyapıtlarından biri. Selim Işık\'ın intiharının ardından, arkadaşı Turgut Özben\'in, onun hayatını araştırmasıyla başlayan derin bir yolculuk.',
      genre: 'Roman',
      readDate: 'Ocak 2025'
    },
    {
      id: 2,
      title: 'Dune',
      author: 'Frank Herbert',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/ef61fb14-1978-4906-a198-5892ec10d608.jpg',
      rating: 5,
      review: 'Bilim kurgu edebiyatının en önemli eserlerinden biri. Arrakis gezegenindeki politik, dini ve ekolojik çatışmaları muhteşem bir evren yaratımıyla anlatıyor.',
      genre: 'Bilim Kurgu',
      readDate: 'Şubat 2025'
    },
    {
      id: 3,
      title: 'Sapiens: İnsan Türünün Kısa Bir Tarihi',
      author: 'Yuval Noah Harari',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/82372206-aab5-4d4e-a51b-5007bf262f96.jpg',
      rating: 4,
      review: 'İnsanlık tarihini farklı bir bakış açısıyla ele alan, bilişsel devrim, tarım devrimi ve bilimsel devrim üzerinden türümüzün gelişimini anlatan etkileyici bir kitap.',
      genre: 'Tarih',
      readDate: 'Mart 2025'
    },
    {
      id: 4,
      title: 'Böyle Söyledi Zerdüşt',
      author: 'Friedrich Nietzsche',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/82f85800-59fa-4331-b0f9-1d732c79bf4e.jpg',
      rating: 5,
      review: 'Nietzsche\'nin en ünlü eserlerinden biri. Üstinsan kavramını ve geleneksel değerlerin yeniden değerlendirilmesini şiirsel bir dille anlatıyor.',
      genre: 'Felsefe',
      readDate: 'Nisan 2025'
    },
    {
      id: 5,
      title: 'Atomic Habits',
      author: 'James Clear',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/612457cb-cdbc-4b03-b2e3-3a1c014a0dcc.jpg',
      rating: 4,
      review: 'Küçük alışkanlıkların nasıl büyük değişimlere yol açabileceğini anlatan pratik bir rehber. Alışkanlık oluşturma ve değiştirme konusunda çok faydalı stratejiler sunuyor.',
      genre: 'Kişisel Gelişim',
      readDate: 'Mayıs 2025'
    },
    {
      id: 6,
      title: 'Steve Jobs',
      author: 'Walter Isaacson',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/573cdd94-1f93-4272-b125-af989fded38c.jpg',
      rating: 4,
      review: 'Apple\'ın kurucu ortağı Steve Jobs\'ın hayatını tüm yönleriyle anlatan kapsamlı bir biyografi. Hem başarıları hem de karanlık yönleriyle Jobs\'ın portresi çiziliyor.',
      genre: 'Biyografi',
      readDate: 'Haziran 2025'
    },
    {
      id: 7,
      title: 'Fahrenheit 451',
      author: 'Ray Bradbury',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/7b86605a-4d0e-490d-a0ce-88f769ade138.jpg',
      rating: 5,
      review: 'Kitapların yakıldığı distopik bir geleceği anlatan, sansür ve medyanın toplum üzerindeki etkisini sorgulayan etkileyici bir roman.',
      genre: 'Bilim Kurgu',
      readDate: 'Temmuz 2025'
    },
    {
      id: 8,
      title: 'İnce Memed',
      author: 'Yaşar Kemal',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/71607cf3-3f14-4acd-a208-1ef08c88f5fa.jpg',
      rating: 5,
      review: 'Türk edebiyatının klasiklerinden, Çukurova\'da adaletsizliklere karşı çıkan bir eşkıyanın hikâyesi. Yaşar Kemal\'in zengin dili ve derin karakter çalışmasıyla unutulmaz bir eser.',
      genre: 'Roman',
      readDate: 'Ağustos 2025'
    }
  ];

  // Filtrelenmiş kitaplar
  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          book.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGenre = selectedGenre ? book.genre === selectedGenre : true;
    return matchesSearch && matchesGenre;
  });

  // Yıldız oluşturma fonksiyonu
  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, index) => (
      <Star 
        key={index} 
        className={`h-4 w-4 ${index < rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-merriweather">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-700 text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">Kitap İncelemeleri</h1>
          <p className="text-xl text-amber-100 max-w-3xl">
            Okuduğum ve beğendiğim kitaplar hakkındaki düşüncelerimi ve tavsiyelerimi bulabilirsiniz.
          </p>
        </div>
      </div>

      {/* Filtreler */}
      <div className="bg-white dark:bg-slate-900 shadow-md py-4 px-6 sticky top-16 z-30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Kitap veya yazar ara..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2 overflow-x-auto pb-2 w-full md:w-auto">
            <Filter className="text-slate-500 h-4 w-4 flex-shrink-0" />
            <Button 
              variant={selectedGenre === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedGenre(null)}
              className="flex-shrink-0"
            >
              Tüm Türler
            </Button>
            
            {genres.map(genre => (
              <Button
                key={genre}
                variant={selectedGenre === genre ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedGenre(genre)}
                className="flex-shrink-0"
              >
                {genre}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Kitap Listesi */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          {filteredBooks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredBooks.map(book => (
                <div key={book.id} className="bg-white dark:bg-slate-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow h-full flex flex-col">
                  <div className="flex md:flex-row flex-col h-full">
                    <div className="md:w-1/3 p-4 flex items-center justify-center bg-slate-100 dark:bg-slate-700">
                      <div className="relative w-32 h-48 shadow-md overflow-hidden">
                        <img 
                          src={book.coverImage} 
                          alt={`${book.title} kitap kapağı`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                    
                    <div className="md:w-2/3 p-6 flex flex-col flex-grow">
                      <div className="mb-2">
                        <span className="bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 text-xs font-medium px-2.5 py-1 rounded">
                          {book.genre}
                        </span>
                        <span className="text-slate-500 dark:text-slate-400 text-sm ml-2">
                          {book.readDate}
                        </span>
                      </div>
                      
                      <h2 className="text-xl font-bold mb-1 text-slate-900 dark:text-white">
                        {book.title}
                      </h2>
                      
                      <p className="text-slate-700 dark:text-slate-300 text-sm mb-2">
                        <span className="italic">Yazar:</span> {book.author}
                      </p>
                      
                      <div className="flex items-center mb-3">
                        {renderStars(book.rating)}
                      </div>
                      
                      <p className="text-slate-600 dark:text-slate-400 text-sm mb-4 flex-grow">
                        {book.review}
                      </p>
                      
                      <Button variant="outline" className="mt-auto self-start">
                        <BookOpen className="h-4 w-4 mr-2" /> İncelemeyi Oku
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <BookMarked className="h-16 w-16 mx-auto text-slate-400 mb-4" />
              <h3 className="text-2xl font-medium text-slate-800 dark:text-slate-200 mb-2">
                Kitap bulunamadı
              </h3>
              <p className="text-slate-600 dark:text-slate-400">
                Arama kriterlerinize uygun kitap bulunamadı. Lütfen farklı bir arama terimi deneyin.
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Books;
