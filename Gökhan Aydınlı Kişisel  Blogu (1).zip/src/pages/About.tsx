
/**
 * Hakkımda sayfası bileşeni - Kullanıcının kendisi, ilgi alanları ve ekipmanları hakkında bilgi verir
 */
import { FC } from 'react';
import { Mail, Camera, Compass, Bookmark, Coffee, Heart, Code } from 'lucide-react';
import { Button } from '../components/ui/button';

const About: FC = () => {
  // Ekipman listesi
  const equipment = [
    { name: 'Sony Alpha A7 III', category: 'Kamera', description: 'Tam kare aynasız kamera' },
    { name: 'Sony 24-70mm f/2.8 GM', category: 'Lens', description: 'Günlük çekimler için zoom lens' },
    { name: 'Sony 85mm f/1.4 GM', category: 'Lens', description: 'Portreler için prime lens' },
    { name: 'DJI Mavic Air 2', category: 'Drone', description: 'Havadan çekimler için' },
    { name: 'MacBook Pro 16"', category: 'Bilgisayar', description: 'Fotoğraf ve video düzenleme için' },
    { name: 'Adobe Lightroom', category: 'Yazılım', description: 'Fotoğraf düzenleme' },
    { name: 'Adobe Photoshop', category: 'Yazılım', description: 'Gelişmiş fotoğraf düzenleme' },
    { name: 'Final Cut Pro X', category: 'Yazılım', description: 'Video düzenleme' }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-merriweather">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-700 text-white py-20 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-8">
          <div className="w-48 h-48 rounded-full border-4 border-white shadow-xl overflow-hidden flex-shrink-0">
            <img 
              src="https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/49c66ad0-dce5-41b3-bd2f-965863b9eb9a.jpg" 
              alt="Gökhan Aydınlı" 
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h1 className="text-4xl font-bold mb-3">Gökhan Aydınlı</h1>
            <p className="text-lg text-indigo-100 mb-6 max-w-2xl">
              Fotoğrafçı, kitap kurdu, gezgin ve teknoloji meraklısı. Hayatın güzelliklerini keşfedip paylaşmaktan keyif alıyorum.
            </p>
            <Button variant="secondary" size="lg">
              <Mail className="mr-2 h-5 w-5" /> İletişime Geç
            </Button>
          </div>
        </div>
      </div>

      {/* Hakkımda */}
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-slate-800 dark:text-white">Hakkımda</h2>
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-8">
            <p className="text-lg text-slate-700 dark:text-slate-200 mb-6">
              Merhaba, ben Gökhan Aydınlı Ticari Gayrimenkul ve Gayrimenkul Yatırımları alanında çalışıyor ve kendi şirketimi yönetiyorum. Fotoğrafçılık, kitap okuma, seyahat etme ve teknoloji ile ilgileniyorum. Bu blog, tüm bu tutkularımı ve deneyimlerimi paylaşmak için oluşturduğum kişisel bir alan.
            </p>
            <p className="text-lg text-slate-700 dark:text-slate-200 mb-6">
              2015 yılından beri fotoğrafçılıkla profesyonel olarak ilgileniyorum. Doğa, mimari ve sokak fotoğrafçılığı en sevdiğim türler arasında. Her fotoğrafta bir hikaye anlatmaya çalışıyorum.
            </p>
            <p className="text-lg text-slate-700 dark:text-slate-200 mb-6">
              Kitaplar ise hayatımın vazgeçilmez bir parçası. Bilim kurgu, felsefe ve tarih kitapları okumayı seviyorum. Bu blogda okuduğum kitaplar hakkındaki düşüncelerimi ve tavsiyelerimi bulabilirsiniz.
            </p>
            <p className="text-lg text-slate-700 dark:text-slate-200">
              Yeni yerler keşfetmek ve farklı kültürleri tanımak benim için büyük bir tutku. Seyahatlerimden edindiğim deneyimleri ve çektiğim fotoğrafları da bu platformda paylaşıyorum.
            </p>
          </div>
        </div>
      </section>

      {/* İlgi Alanları */}
      <section className="py-16 px-6 bg-slate-100 dark:bg-slate-900">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-slate-800 dark:text-white">İlgi Alanlarım</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Fotoğrafçılık */}
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col">
              <div className="w-12 h-12 bg-violet-100 dark:bg-violet-900/30 rounded-full flex items-center justify-center mb-4">
                <Camera className="h-6 w-6 text-violet-600 dark:text-violet-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">Fotoğrafçılık</h3>
              <p className="text-slate-600 dark:text-slate-300 flex-grow">
                Doğa, şehir ve sokak fotoğrafçılığı. Anı yakalamak ve hikayeler anlatmak için fotoğraf çekiyorum.
              </p>
            </div>
            
            {/* Seyahat */}
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col">
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mb-4">
                <Compass className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">Seyahat</h3>
              <p className="text-slate-600 dark:text-slate-300 flex-grow">
                Yeni yerler keşfetmek, farklı kültürleri tanımak ve unutulmaz deneyimler yaşamak için seyahat ediyorum.
              </p>
            </div>
            
            {/* Kitaplar */}
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col">
              <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mb-4">
                <Bookmark className="h-6 w-6 text-amber-600 dark:text-amber-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">Kitaplar</h3>
              <p className="text-slate-600 dark:text-slate-300 flex-grow">
                Bilim kurgu, felsefe ve tarih kitapları okumayı seviyorum. Her kitap yeni bir dünya keşfetmek gibi.
              </p>
            </div>
            
            {/* Kahve */}
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col">
              <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mb-4">
                <Coffee className="h-6 w-6 text-amber-600 dark:text-amber-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">Kahve</h3>
              <p className="text-slate-600 dark:text-slate-300 flex-grow">
                İyi bir kahve, günümü güzelleştiren en önemli detaylardan biri. Farklı demleme yöntemleri ve kahve çeşitlerini denemeyi seviyorum.
              </p>
            </div>
            
            {/* Sanat */}
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col">
              <div className="w-12 h-12 bg-pink-100 dark:bg-pink-900/30 rounded-full flex items-center justify-center mb-4">
                <Heart className="h-6 w-6 text-pink-600 dark:text-pink-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">Sanat</h3>
              <p className="text-slate-600 dark:text-slate-300 flex-grow">
                Müzeler, galeriler ve sanat eserleri. Farklı sanat akımlarını ve sanatçıları keşfetmeyi seviyorum.
              </p>
            </div>
            
            {/* Teknoloji */}
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-4">
                <Code className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">Teknoloji</h3>
              <p className="text-slate-600 dark:text-slate-300 flex-grow">
                Yazılım, donanım ve yeni teknolojileri takip etmeyi seviyorum. Teknolojinin hayatımızı nasıl değiştirdiğini gözlemlemek beni heyecanlandırıyor.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Ekipmanlarım */}
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-slate-800 dark:text-white">Ekipmanlarım</h2>
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-slate-100 dark:bg-slate-700">
                <tr>
                  <th className="text-left py-4 px-6 text-slate-700 dark:text-slate-200">Ekipman</th>
                  <th className="text-left py-4 px-6 text-slate-700 dark:text-slate-200">Kategori</th>
                  <th className="text-left py-4 px-6 text-slate-700 dark:text-slate-200 hidden md:table-cell">Açıklama</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {equipment.map((item, index) => (
                  <tr key={index} className="hover:bg-slate-50 dark:hover:bg-slate-750">
                    <td className="py-4 px-6 text-slate-800 dark:text-slate-200 font-medium">{item.name}</td>
                    <td className="py-4 px-6 text-slate-600 dark:text-slate-300">{item.category}</td>
                    <td className="py-4 px-6 text-slate-600 dark:text-slate-300 hidden md:table-cell">{item.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
