<?php
/**
 * React uygulamasından export edilen JSON verilerini MySQL'e import eden script
 */

require_once '../config/database.php';

class JsonImporter {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * JSON dosyasından verileri import et
     */
    public function importFromJson($jsonFile) {
        if (!file_exists($jsonFile)) {
            die("JSON dosyası bulunamadı: $jsonFile");
        }
        
        $jsonData = file_get_contents($jsonFile);
        $data = json_decode($jsonData, true);
        
        if (!$data) {
            die("JSON verisi okunamadı!");
        }
        
        echo "JSON verisi başarıyla okundu.\n";
        echo "Export tarihi: " . $data['exportDate'] . "\n";
        echo "Versiyon: " . $data['version'] . "\n\n";
        
        // Import işlemleri
        $this->importProjects($data['projects'] ?? []);
        $this->importBlogPosts($data['blogPosts'] ?? []);
        $this->importPhotos($data['photos'] ?? []);
        $this->importBooks($data['books'] ?? []);
        $this->importSiteSettings($data['siteSettings'] ?? []);
        
        echo "\n✅ Tüm veriler başarıyla import edildi!\n";
    }
    
    /**
     * Projeleri import et
     */
    private function importProjects($projects) {
        echo "📂 Projeler import ediliyor...\n";
        
        foreach ($projects as $project) {
            $query = "INSERT INTO projects (title, description, image_url, order_index, is_published, created_at, updated_at) 
                      VALUES (:title, :description, :image_url, :order_index, :is_published, :created_at, :updated_at)
                      ON DUPLICATE KEY UPDATE 
                      description = VALUES(description),
                      image_url = VALUES(image_url),
                      order_index = VALUES(order_index),
                      is_published = VALUES(is_published),
                      updated_at = VALUES(updated_at)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':title', $project['title']);
            $stmt->bindParam(':description', $project['description']);
            $stmt->bindParam(':image_url', $project['imageUrl']);
            $stmt->bindParam(':order_index', $project['order']);
            $stmt->bindParam(':is_published', $project['isPublished'], PDO::PARAM_BOOL);
            $stmt->bindParam(':created_at', $project['createdAt']);
            $stmt->bindParam(':updated_at', $project['updatedAt']);
            
            if ($stmt->execute()) {
                echo "  ✅ " . $project['title'] . "\n";
            } else {
                echo "  ❌ " . $project['title'] . " - Hata!\n";
            }
        }
    }
    
    /**
     * Blog yazılarını import et
     */
    private function importBlogPosts($blogPosts) {
        echo "📝 Blog yazıları import ediliyor...\n";
        
        foreach ($blogPosts as $post) {
            $query = "INSERT INTO blog_posts (title, slug, excerpt, content, category, tags, cover_image, is_published, created_at, updated_at) 
                      VALUES (:title, :slug, :excerpt, :content, :category, :tags, :cover_image, :is_published, :created_at, :updated_at)
                      ON DUPLICATE KEY UPDATE 
                      title = VALUES(title),
                      excerpt = VALUES(excerpt),
                      content = VALUES(content),
                      category = VALUES(category),
                      tags = VALUES(tags),
                      cover_image = VALUES(cover_image),
                      is_published = VALUES(is_published),
                      updated_at = VALUES(updated_at)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':title', $post['title']);
            $stmt->bindParam(':slug', $post['slug']);
            $stmt->bindParam(':excerpt', $post['excerpt']);
            $stmt->bindParam(':content', $post['content']);
            $stmt->bindParam(':category', $post['category']);
            $stmt->bindParam(':tags', $post['tags']);
            $stmt->bindParam(':cover_image', $post['coverImage']);
            $stmt->bindParam(':is_published', $post['isPublished'], PDO::PARAM_BOOL);
            $stmt->bindParam(':created_at', $post['createdAt']);
            $stmt->bindParam(':updated_at', $post['updatedAt']);
            
            if ($stmt->execute()) {
                echo "  ✅ " . $post['title'] . "\n";
            } else {
                echo "  ❌ " . $post['title'] . " - Hata!\n";
            }
        }
    }
    
    /**
     * Fotoğrafları import et
     */
    private function importPhotos($photos) {
        echo "📸 Fotoğraflar import ediliyor...\n";
        
        foreach ($photos as $photo) {
            $query = "INSERT INTO photos (title, description, category, image_url, order_index, is_published, created_at, updated_at) 
                      VALUES (:title, :description, :category, :image_url, :order_index, :is_published, :created_at, :updated_at)
                      ON DUPLICATE KEY UPDATE 
                      description = VALUES(description),
                      category = VALUES(category),
                      image_url = VALUES(image_url),
                      order_index = VALUES(order_index),
                      is_published = VALUES(is_published),
                      updated_at = VALUES(updated_at)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':title', $photo['title']);
            $stmt->bindParam(':description', $photo['description']);
            $stmt->bindParam(':category', $photo['category']);
            $stmt->bindParam(':image_url', $photo['imageUrl']);
            $stmt->bindParam(':order_index', $photo['orderIndex']);
            $stmt->bindParam(':is_published', $photo['isPublished'], PDO::PARAM_BOOL);
            $stmt->bindParam(':created_at', $photo['createdAt']);
            $stmt->bindParam(':updated_at', $photo['updatedAt']);
            
            if ($stmt->execute()) {
                echo "  ✅ " . $photo['title'] . "\n";
            } else {
                echo "  ❌ " . $photo['title'] . " - Hata!\n";
            }
        }
    }
    
    /**
     * Kitapları import et
     */
    private function importBooks($books) {
        echo "📚 Kitaplar import ediliyor...\n";
        
        foreach ($books as $book) {
            $query = "INSERT INTO books (title, author, genre, rating, review, cover_image, is_published, created_at, updated_at) 
                      VALUES (:title, :author, :genre, :rating, :review, :cover_image, :is_published, :created_at, :updated_at)
                      ON DUPLICATE KEY UPDATE 
                      author = VALUES(author),
                      genre = VALUES(genre),
                      rating = VALUES(rating),
                      review = VALUES(review),
                      cover_image = VALUES(cover_image),
                      is_published = VALUES(is_published),
                      updated_at = VALUES(updated_at)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':title', $book['title']);
            $stmt->bindParam(':author', $book['author']);
            $stmt->bindParam(':genre', $book['genre']);
            $stmt->bindParam(':rating', $book['rating']);
            $stmt->bindParam(':review', $book['review']);
            $stmt->bindParam(':cover_image', $book['coverImage']);
            $stmt->bindParam(':is_published', $book['isPublished'], PDO::PARAM_BOOL);
            $stmt->bindParam(':created_at', $book['createdAt']);
            $stmt->bindParam(':updated_at', $book['updatedAt']);
            
            if ($stmt->execute()) {
                echo "  ✅ " . $book['title'] . "\n";
            } else {
                echo "  ❌ " . $book['title'] . " - Hata!\n";
            }
        }
    }
    
    /**
     * Site ayarlarını import et
     */
    private function importSiteSettings($settings) {
        echo "⚙️ Site ayarları import ediliyor...\n";
        
        foreach ($settings as $setting) {
            $query = "INSERT INTO site_settings (setting_key, setting_value, setting_type, updated_at) 
                      VALUES (:setting_key, :setting_value, :setting_type, NOW())
                      ON DUPLICATE KEY UPDATE 
                      setting_value = VALUES(setting_value),
                      setting_type = VALUES(setting_type),
                      updated_at = VALUES(updated_at)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':setting_key', $setting['settingKey']);
            $stmt->bindParam(':setting_value', $setting['settingValue']);
            $stmt->bindParam(':setting_type', $setting['settingType']);
            
            if ($stmt->execute()) {
                echo "  ✅ " . $setting['settingKey'] . "\n";
            } else {
                echo "  ❌ " . $setting['settingKey'] . " - Hata!\n";
            }
        }
    }
}

// Kullanım
if ($argc < 2) {
    echo "Kullanım: php import_json.php <json_dosya_yolu>\n";
    echo "Örnek: php import_json.php ../exports/adakale_export_2024-01-01.json\n";
    exit(1);
}

$jsonFile = $argv[1];
$importer = new JsonImporter();
$importer->importFromJson($jsonFile);
?>