
/**
 * Admin paneli sayfası - Güvenli admin paneli ve içerik yönetimi
 */
import { FC, useState, useEffect } from 'react';
import { Settings, Users, FileText, Camera, BookOpen, BarChart3, Plus, Edit, Trash2, Eye, LogOut, Save, X, MapPin, Image, Globe, Leaf, Palette } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Switch } from '../components/ui/switch';
import { useAuthStore } from '../stores/authStore';
import { useProjectStore, ProjectItem } from '../stores/projectStore';
import AdminLogin from '../components/AdminLogin';

const Admin: FC = () => {
  const { isAuthenticated, logout, checkSession } = useAuthStore();
  const { 
    projects, 
    addProject, 
    updateProject, 
    deleteProject, 
    getPublishedProjects 
  } = useProjectStore();

  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [showAddPhoto, setShowAddPhoto] = useState(false);
  const [showAddBook, setShowAddBook] = useState(false);
  const [showAddBlog, setShowAddBlog] = useState(false);
  const [showAddProject, setShowAddProject] = useState(false);
  const [editingProject, setEditingProject] = useState<ProjectItem | null>(null);
  const [showProjectDetails, setShowProjectDetails] = useState(false);
  const [selectedProjectForDetails, setSelectedProjectForDetails] = useState<ProjectItem | null>(null);

  // Session kontrolü
  useEffect(() => {
    const interval = setInterval(() => {
      checkSession();
    }, 60000); // Her dakika kontrol et

    return () => clearInterval(interval);
  }, [checkSession]);

  // Yeni fotoğraf formu
  const [newPhoto, setNewPhoto] = useState({
    title: '',
    description: '',
    category: '',
    imageUrl: ''
  });

  // Yeni kitap formu
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    genre: '',
    rating: 5,
    review: '',
    coverUrl: ''
  });

  // Yeni blog yazısı formu
  const [newBlog, setNewBlog] = useState({
    title: '',
    excerpt: '',
    content: '',
    category: '',
    tags: '',
    coverUrl: ''
  });

  // Yeni proje formu
  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    imageUrl: '',
    isPublished: true,
    order: projects.length + 1
  });

  // Login başarılı callback
  const handleLoginSuccess = () => {
    // Login başarılı, component yeniden render edilecek
  };

  // Logout handler
  const handleLogout = () => {
    logout();
  };

  // Örnek istatistikler
  const stats = [
    { title: 'Blog Yazıları', value: '12', icon: FileText, color: 'text-blue-600' },
    { title: 'Fotoğraf Galerisi', value: '48', icon: Camera, color: 'text-green-600' },
    { title: 'Kitap İncelemeleri', value: '8', icon: BookOpen, color: 'text-amber-600' },
    { title: 'Adakale Projesi', value: projects.length.toString(), icon: Leaf, color: 'text-emerald-600' }
  ];

  // Form handlers
  const handleAddPhoto = () => {
    console.log('Yeni fotoğraf eklendi:', newPhoto);
    setNewPhoto({ title: '', description: '', category: '', imageUrl: '' });
    setShowAddPhoto(false);
  };

  const handleAddBook = () => {
    console.log('Yeni kitap eklendi:', newBook);
    setNewBook({ title: '', author: '', genre: '', rating: 5, review: '', coverUrl: '' });
    setShowAddBook(false);
  };

  const handleAddBlog = () => {
    console.log('Yeni blog yazısı eklendi:', newBlog);
    setNewBlog({ title: '', excerpt: '', content: '', category: '', tags: '', coverUrl: '' });
    setShowAddBlog(false);
  };

  const handleAddProject = () => {
    addProject(newProject);
    setNewProject({
      title: '',
      description: '',
      imageUrl: '',
      isPublished: true,
      order: projects.length + 1
    });
    setShowAddProject(false);
  };

  const handleEditProject = (project: ProjectItem) => {
    setEditingProject({ ...project });
  };

  const handleUpdateProject = () => {
    if (editingProject) {
      updateProject(editingProject.id, editingProject);
      setEditingProject(null);
    }
  };

  const handleDeleteProject = (id: number) => {
    if (confirm('Bu projeyi silmek istediğinizden emin misiniz?')) {
      deleteProject(id);
    }
  };

  // Eğer authenticated değilse login ekranını göster
  if (!isAuthenticated || !checkSession()) {
    return <AdminLogin onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-merriweather">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 shadow-md border-b border-slate-200 dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Settings className="h-8 w-8 text-violet-600 dark:text-violet-400 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Admin Panel</h1>
                <p className="text-sm text-slate-600 dark:text-slate-400">Güvenli İçerik Yönetimi</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline">
                <Eye className="h-4 w-4 mr-2" />
                Siteyi Görüntüle
              </Button>
              <Button variant="destructive" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Güvenli Çıkış
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="projects">Adakale Görselleri</TabsTrigger>
            <TabsTrigger value="photos">Fotoğraflar</TabsTrigger>
            <TabsTrigger value="books">Kitaplar</TabsTrigger>
            <TabsTrigger value="blogs">Blog Yazıları</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-slate-600 dark:text-slate-400">{stat.title}</p>
                        <p className="text-3xl font-bold text-slate-900 dark:text-white">{stat.value}</p>
                      </div>
                      <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Güvenlik Bilgileri</CardTitle>
                  <CardDescription>Sistem güvenlik durumu</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <span className="text-sm font-medium text-green-800 dark:text-green-300">SSL Sertifikası</span>
                      <span className="text-xs bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200 px-2 py-1 rounded">Aktif</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <span className="text-sm font-medium text-green-800 dark:text-green-300">Session Güvenliği</span>
                      <span className="text-xs bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200 px-2 py-1 rounded">Aktif</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <span className="text-sm font-medium text-green-800 dark:text-green-300">Brute Force Koruması</span>
                      <span className="text-xs bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200 px-2 py-1 rounded">Aktif</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Hızlı İşlemler</CardTitle>
                  <CardDescription>Sık kullanılan yönetim işlemleri</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button onClick={() => setShowAddProject(true)} className="w-full justify-start bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-700 hover:to-emerald-800">
                      <Leaf className="h-4 w-4 mr-2" />
                      Yeni Sürdürebilirlik İçeriği
                    </Button>
                    <Button onClick={() => setShowAddBlog(true)} variant="outline" className="w-full justify-start">
                      <Plus className="h-4 w-4 mr-2" />
                      Yeni Blog Yazısı Ekle
                    </Button>
                    <Button onClick={() => setShowAddPhoto(true)} variant="outline" className="w-full justify-start">
                      <Plus className="h-4 w-4 mr-2" />
                      Yeni Fotoğraf Ekle
                    </Button>
                    <Button onClick={() => setShowAddBook(true)} variant="outline" className="w-full justify-start">
                      <Plus className="h-4 w-4 mr-2" />
                      Yeni Kitap İncelemesi Ekle
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Proje Detayları Modal */}
            {showProjectDetails && selectedProjectForDetails && (
              <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                <div className="bg-white dark:bg-slate-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                  <div className="sticky top-0 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 p-6 flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                      Proje Hakkında
                    </h2>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setShowProjectDetails(false);
                        setSelectedProjectForDetails(null);
                      }}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                  
                  <div className="p-6 space-y-8">
                    {/* Proje Görseli */}
                    <div className="aspect-video rounded-lg overflow-hidden">
                      <img 
                        src={selectedProjectForDetails.imageUrl} 
                        alt={selectedProjectForDetails.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    {/* Proje Felsefesi */}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl p-6">
                      <blockquote className="text-lg italic text-green-800 dark:text-green-300 text-center">
                        "Bir Gayrimenkul'den filizlenen, Birlikte büyümek, birlikte yaşamak, doğayla uyum içinde var olmak felsefesidir."
                      </blockquote>
                      <p className="text-slate-700 dark:text-slate-300 mt-4">
                        Proje, belirli bir hedefe ulaşmak için planlanmış ve uygulanan işler, araştırmalar veya etkinlikler anlamına gelir.
                      </p>
                    </div>
                    
                    {/* Bu Proje Aynı Zamanda */}
                    <div>
                      <h3 className="text-2xl font-bold mb-6 text-slate-900 dark:text-white">
                        Bu Proje (Project) Aynı Zamanda:
                      </h3>
                      
                      <div className="space-y-6">
                        {/* Planlama */}
                        <div className="bg-white dark:bg-slate-700 rounded-lg p-6 border border-slate-200 dark:border-slate-600">
                          <h4 className="text-xl font-semibold mb-3 text-blue-700 dark:text-blue-400 flex items-center">
                            <Calendar className="h-5 w-5 mr-2" />
                            Planlama
                          </h4>
                          <p className="text-slate-700 dark:text-slate-300">
                            Belirli bir konuda, belirli bir süre içinde gerçekleştirilecek işlerin detaylı bir şekilde planlanması. 
                            İşin uzmanlarının bu çalışmaları sergilemek ve eğitim vermek fırsatının sunulması.
                          </p>
                        </div>
                        
                        {/* Hedef */}
                        <div className="bg-white dark:bg-slate-700 rounded-lg p-6 border border-slate-200 dark:border-slate-600">
                          <h4 className="text-xl font-semibold mb-3 text-amber-700 dark:text-amber-400 flex items-center">
                            <Leaf className="h-5 w-5 mr-2" />
                            Hedef
                          </h4>
                          <p className="text-slate-700 dark:text-slate-300">
                            Belirli bir amaca ulaşmak için yapılan çalışma.
                          </p>
                        </div>
                        
                        {/* Yürütme */}
                        <div className="bg-white dark:bg-slate-700 rounded-lg p-6 border border-slate-200 dark:border-slate-600">
                          <h4 className="text-xl font-semibold mb-3 text-green-700 dark:text-green-400 flex items-center">
                            <Users className="h-5 w-5 mr-2" />
                            Yürütme
                          </h4>
                          <p className="text-slate-700 dark:text-slate-300">
                            Projeyi hayata geçirecek faaliyetlerin ve süreçlerin yönetilmesi. Yaşamsal faaliyetler 
                            sürdürülürken sürdürülebilir bahçecilik, çiftçilik, sera faaliyetleri yürütülürken 
                            geleneksel yöntemler, sıfır atık ve ata tohumlarıyla üretim esaslarıyla faaliyetlerinin 
                            devam ettirmek esasıyla kurgulanmış bir birlikte faaliyetler bütünüdür.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="projects" className="mt-6">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Project Adakale Yönetimi</h2>
                <p className="text-slate-600 dark:text-slate-400">Adakale projesi içeriklerini yönetin</p>
              </div>
              <Button onClick={() => setShowAddProject(true)} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="h-4 w-4 mr-2" />
                Yeni İçerik Ekle
              </Button>
            </div>

            {/* Yeni Proje Ekleme Formu */}
            {showAddProject && (
              <Card className="mb-6 border-green-200 dark:border-green-800">
                <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
                  <CardTitle className="flex items-center">
                    <Leaf className="h-5 w-5 mr-2 text-green-600" />
                    Yeni Sürdürebilirlik İçeriği Ekle
                  </CardTitle>
                  <CardDescription>
                    Permakültür, topluluk etkinlikleri veya sanat projesi içeriği ekleyin
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="İçerik başlığı"
                      value={newProject.title}
                      onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                    />
                    <Input
                      placeholder="Resim URL'si"
                      value={newProject.imageUrl}
                      onChange={(e) => setNewProject({ ...newProject, imageUrl: e.target.value })}
                    />
                    <div className="md:col-span-2">
                      <Textarea
                        placeholder="İçerik açıklaması"
                        value={newProject.description}
                        onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                        className="min-h-[100px]"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="publish"
                        checked={newProject.isPublished}
                        onCheckedChange={(checked) => setNewProject({ ...newProject, isPublished: checked })}
                      />
                      <label htmlFor="publish" className="text-sm font-medium">
                        Hemen Yayınla
                      </label>
                    </div>
                    <div className="md:col-span-2 flex gap-2">
                      <Button onClick={handleAddProject} className="bg-emerald-600 hover:bg-emerald-700">
                        <Save className="h-4 w-4 mr-2" />
                        Kaydet
                      </Button>
                      <Button variant="outline" onClick={() => setShowAddProject(false)}>
                        <X className="h-4 w-4 mr-2" />
                        İptal
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Proje Düzenleme Formu */}
            {editingProject && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Edit className="h-5 w-5 mr-2 text-blue-600" />
                    İçerik Düzenle
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="İçerik başlığı"
                      value={editingProject.title}
                      onChange={(e) => setEditingProject({ ...editingProject, title: e.target.value })}
                    />
                    <Input
                      placeholder="Resim URL'si"
                      value={editingProject.imageUrl}
                      onChange={(e) => setEditingProject({ ...editingProject, imageUrl: e.target.value })}
                    />
                    <div className="md:col-span-2">
                      <Textarea
                        placeholder="İçerik açıklaması"
                        value={editingProject.description}
                        onChange={(e) => setEditingProject({ ...editingProject, description: e.target.value })}
                        className="min-h-[100px]"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="edit-publish"
                        checked={editingProject.isPublished}
                        onCheckedChange={(checked) => setEditingProject({ ...editingProject, isPublished: checked })}
                      />
                      <label htmlFor="edit-publish" className="text-sm font-medium">
                        Yayında
                      </label>
                    </div>
                    <div className="md:col-span-2 flex gap-2">
                      <Button onClick={handleUpdateProject} className="bg-blue-600 hover:bg-blue-700">
                        <Save className="h-4 w-4 mr-2" />
                        Güncelle
                      </Button>
                      <Button variant="outline" onClick={() => setEditingProject(null)}>
                        <X className="h-4 w-4 mr-2" />
                        İptal
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Proje Listesi */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Card key={project.id}>
                  <div className="relative">
                    <div className="aspect-video bg-slate-200 dark:bg-slate-700 rounded-t-lg overflow-hidden">
                      {project.imageUrl ? (
                        <img 
                          src={project.imageUrl} 
                          alt={project.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Image className="h-8 w-8 text-slate-400" />
                        </div>
                      )}
                    </div>
                    <div className="absolute top-2 right-2">
                      <span className={`text-xs px-2 py-1 rounded ${
                        project.isPublished 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {project.isPublished ? 'Yayında' : 'Taslak'}
                      </span>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-medium text-slate-900 dark:text-white mb-2">{project.title}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 line-clamp-2">
                      {project.description}
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {new Date(project.updatedAt).toLocaleDateString('tr-TR')}
                      </span>
                      <div className="flex gap-1">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => {
                            setSelectedProjectForDetails(project);
                            setShowProjectDetails(true);
                          }}
                        >
                          <Eye className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleEditProject(project)}>
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleDeleteProject(project.id)}>
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Diğer tablar aynı kalacak - önceki koddan devam ediyor */}
          <TabsContent value="photos" className="mt-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Fotoğraf Yönetimi</h2>
              <Button onClick={() => setShowAddPhoto(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Fotoğraf Ekle
              </Button>
            </div>

            {showAddPhoto && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Yeni Fotoğraf Ekle</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Fotoğraf başlığı"
                      value={newPhoto.title}
                      onChange={(e) => setNewPhoto({ ...newPhoto, title: e.target.value })}
                    />
                    <Input
                      placeholder="Kategori"
                      value={newPhoto.category}
                      onChange={(e) => setNewPhoto({ ...newPhoto, category: e.target.value })}
                    />
                    <div className="md:col-span-2">
                      <Input
                        placeholder="Fotoğraf URL'si"
                        value={newPhoto.imageUrl}
                        onChange={(e) => setNewPhoto({ ...newPhoto, imageUrl: e.target.value })}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Textarea
                        placeholder="Fotoğraf açıklaması"
                        value={newPhoto.description}
                        onChange={(e) => setNewPhoto({ ...newPhoto, description: e.target.value })}
                      />
                    </div>
                    <div className="md:col-span-2 flex gap-2">
                      <Button onClick={handleAddPhoto}>Ekle</Button>
                      <Button variant="outline" onClick={() => setShowAddPhoto(false)}>İptal</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((index) => (
                <Card key={index}>
                  <div className="aspect-square bg-slate-200 dark:bg-slate-700 rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <h3 className="font-medium text-slate-900 dark:text-white mb-2">Fotoğraf {index}</h3>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-600 dark:text-slate-400">Manzara</span>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline">
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="books" className="mt-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Kitap Yönetimi</h2>
              <Button onClick={() => setShowAddBook(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Kitap Ekle
              </Button>
            </div>

            {showAddBook && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Yeni Kitap İncelemesi Ekle</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Kitap adı"
                      value={newBook.title}
                      onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                    />
                    <Input
                      placeholder="Yazar"
                      value={newBook.author}
                      onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                    />
                    <Input
                      placeholder="Tür"
                      value={newBook.genre}
                      onChange={(e) => setNewBook({ ...newBook, genre: e.target.value })}
                    />
                    <Input
                      type="number"
                      min="1"
                      max="5"
                      placeholder="Puan (1-5)"
                      value={newBook.rating}
                      onChange={(e) => setNewBook({ ...newBook, rating: parseInt(e.target.value) })}
                    />
                    <div className="md:col-span-2">
                      <Input
                        placeholder="Kapak resmi URL'si"
                        value={newBook.coverUrl}
                        onChange={(e) => setNewBook({ ...newBook, coverUrl: e.target.value })}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Textarea
                        placeholder="Kitap incelemesi"
                        value={newBook.review}
                        onChange={(e) => setNewBook({ ...newBook, review: e.target.value })}
                        className="min-h-[100px]"
                      />
                    </div>
                    <div className="md:col-span-2 flex gap-2">
                      <Button onClick={handleAddBook}>Ekle</Button>
                      <Button variant="outline" onClick={() => setShowAddBook(false)}>İptal</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="w-16 h-20 bg-slate-200 dark:bg-slate-700 rounded"></div>
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-900 dark:text-white mb-1">Kitap {index}</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">Yazar Adı</p>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-slate-600 dark:text-slate-400">Roman</span>
                          <div className="flex gap-1">
                            <Button size="sm" variant="outline">
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="blogs" className="mt-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Blog Yazısı Yönetimi</h2>
              <Button onClick={() => setShowAddBlog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Yazı Ekle
              </Button>
            </div>

            {showAddBlog && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Yeni Blog Yazısı Ekle</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Yazı başlığı"
                      value={newBlog.title}
                      onChange={(e) => setNewBlog({ ...newBlog, title: e.target.value })}
                    />
                    <Input
                      placeholder="Kategori"
                      value={newBlog.category}
                      onChange={(e) => setNewBlog({ ...newBlog, category: e.target.value })}
                    />
                    <Input
                      placeholder="Etiketler (virgülle ayırın)"
                      value={newBlog.tags}
                      onChange={(e) => setNewBlog({ ...newBlog, tags: e.target.value })}
                    />
                    <Input
                      placeholder="Kapak resmi URL'si"
                      value={newBlog.coverUrl}
                      onChange={(e) => setNewBlog({ ...newBlog, coverUrl: e.target.value })}
                    />
                    <div className="md:col-span-2">
                      <Textarea
                        placeholder="Kısa açıklama"
                        value={newBlog.excerpt}
                        onChange={(e) => setNewBlog({ ...newBlog, excerpt: e.target.value })}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Textarea
                        placeholder="Yazı içeriği"
                        value={newBlog.content}
                        onChange={(e) => setNewBlog({ ...newBlog, content: e.target.value })}
                        className="min-h-[200px]"
                      />
                    </div>
                    <div className="md:col-span-2 flex gap-2">
                      <Button onClick={handleAddBlog}>Ekle</Button>
                      <Button variant="outline" onClick={() => setShowAddBlog(false)}>İptal</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 gap-6">
              {[1, 2, 3, 4].map((index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="w-24 h-16 bg-slate-200 dark:bg-slate-700 rounded"></div>
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-900 dark:text-white mb-1">Blog Yazısı {index}</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">Kısa açıklama buraya gelecek...</p>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-slate-600 dark:text-slate-400">Fotoğrafçılık</span>
                          <div className="flex gap-1">
                            <Button size="sm" variant="outline">
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
