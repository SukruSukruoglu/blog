<?php
/**
 * Projects API endpoint for Adakale Project
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/database.php';

class ProjectsAPI {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * Tüm yayınlanmış projeleri getir
     */
    public function getPublishedProjects() {
        $query = "SELECT * FROM projects WHERE is_published = 1 ORDER BY order_index ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        $projects = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $projects[] = array(
                'id' => $row['id'],
                'title' => $row['title'],
                'description' => $row['description'],
                'imageUrl' => $row['image_url'],
                'isPublished' => (bool)$row['is_published'],
                'order' => $row['order_index'],
                'createdAt' => $row['created_at'],
                'updatedAt' => $row['updated_at']
            );
        }
        
        return $projects;
    }
    
    /**
     * Yeni proje ekle
     */
    public function addProject($data) {
        $query = "INSERT INTO projects (title, description, image_url, is_published, order_index) 
                  VALUES (:title, :description, :image_url, :is_published, :order_index)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':title', $data['title']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':image_url', $data['imageUrl']);
        $stmt->bindParam(':is_published', $data['isPublished']);
        $stmt->bindParam(':order_index', $data['order']);
        
        if ($stmt->execute()) {
            return array('success' => true, 'id' => $this->conn->lastInsertId());
        }
        
        return array('success' => false);
    }
    
    /**
     * Proje güncelle
     */
    public function updateProject($id, $data) {
        $query = "UPDATE projects SET 
                  title = :title, 
                  description = :description, 
                  image_url = :image_url, 
                  is_published = :is_published, 
                  order_index = :order_index,
                  updated_at = CURRENT_TIMESTAMP
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':title', $data['title']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':image_url', $data['imageUrl']);
        $stmt->bindParam(':is_published', $data['isPublished']);
        $stmt->bindParam(':order_index', $data['order']);
        
        return array('success' => $stmt->execute());
    }
    
    /**
     * Proje sil
     */
    public function deleteProject($id) {
        $query = "DELETE FROM projects WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        return array('success' => $stmt->execute());
    }
}

// API endpoint handling
$method = $_SERVER['REQUEST_METHOD'];
$api = new ProjectsAPI();

switch ($method) {
    case 'GET':
        echo json_encode($api->getPublishedProjects());
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        echo json_encode($api->addProject($data));
        break;
        
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'];
        echo json_encode($api->updateProject($id, $data));
        break;
        
    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        echo json_encode($api->deleteProject($data['id']));
        break;
        
    default:
        http_response_code(405);
        echo json_encode(array('error' => 'Method not allowed'));
        break;
}
?>
