<?php
/**
 * File upload handler for Adakale Project
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$uploadDir = '../uploads/';
$allowedTypes = array('jpg', 'jpeg', 'png', 'gif', 'webp');
$maxFileSize = 5 * 1024 * 1024; // 5MB

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['image'])) {
        echo json_encode(array('success' => false, 'error' => 'No file uploaded'));
        exit;
    }
    
    $file = $_FILES['image'];
    $fileName = $file['name'];
    $fileSize = $file['size'];
    $fileTmpName = $file['tmp_name'];
    $fileError = $file['error'];
    
    if ($fileError !== UPLOAD_ERR_OK) {
        echo json_encode(array('success' => false, 'error' => 'Upload error'));
        exit;
    }
    
    if ($fileSize > $maxFileSize) {
        echo json_encode(array('success' => false, 'error' => 'File too large'));
        exit;
    }
    
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    
    if (!in_array($fileExt, $allowedTypes)) {
        echo json_encode(array('success' => false, 'error' => 'Invalid file type'));
        exit;
    }
    
    // Generate unique filename
    $newFileName = uniqid() . '_' . time() . '.' . $fileExt;
    $uploadPath = $uploadDir . $newFileName;
    
    if (move_uploaded_file($fileTmpName, $uploadPath)) {
        $imageUrl = 'uploads/' . $newFileName;
        echo json_encode(array(
            'success' => true, 
            'imageUrl' => $imageUrl,
            'filename' => $newFileName
        ));
    } else {
        echo json_encode(array('success' => false, 'error' => 'Failed to move file'));
    }
} else {
    http_response_code(405);
    echo json_encode(array('error' => 'Method not allowed'));
}
?>
