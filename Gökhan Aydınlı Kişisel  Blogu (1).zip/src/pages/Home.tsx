
/**
 * Ana sayfa bileşeni - Blog, fotoğraflar ve kitaplar için giriş sayfası
 */
import { FC } from 'react';
import { ArrowRight, BookOpen, Camera, FileText } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Link } from 'react-router';
import ProjectAdakale from '../components/ProjectAdakale';

const Home: FC = () => {
  return (
    <div className="min-h-screen font-EduQLDHand">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-violet-950 to-slate-900 py-20 px-6 text-white">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight font-EduQLDHand">
              Gökhan Aydınlı
            </h1>
            <p className="text-xl text-violet-200 mb-8 max-w-2xl mx-auto lg:mx-0">
              Hayata, kitaplara, doğa, ekonomi,sürdülebilirlik,  fotograf, gayrimenkul  ve diğer ilgi alanlarıma dair kişisel blog sayfama hoşgeldiniz.
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              <Button asChild size="lg">
                <Link to="/blog">
                  Blog Yazılarım <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/hakkimda">
                  Hakkımda
                </Link>
              </Button>
            </div>
          </div>
          <div className="lg:w-1/2 flex justify-center">
            <div className="relative">
              {/* Neon çerçeve efekti */}
              <div className="w-80 h-80 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 absolute blur-md opacity-70"></div>
              <div className="w-80 h-80 rounded-full border-4 border-white shadow-[0_0_25px_rgba(255,255,255,0.5)] relative overflow-hidden">
                <img 
                  src="https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/49c66ad0-dce5-41b3-bd2f-965863b9eb9a.jpg" 
                  alt="Gökhan Aydınlı" 
                  className="w-full h-full object-cover"
                />
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Kategoriler */}
      <section className="py-20 px-6 bg-slate-50 dark:bg-slate-900">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16 text-slate-800 dark:text-white">
            Neler Paylaşıyorum?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Blog */}
            <div className="bg-white dark:bg-slate-800 rounded-lg p-8 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-violet-100 dark:bg-violet-900/30 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-violet-200 dark:group-hover:bg-violet-800/50 transition-colors">
                <FileText className="h-8 w-8 text-violet-600 dark:text-violet-400" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Blog Yazıları</h3>
              <p className="text-slate-600 dark:text-slate-300 mb-6">
                Hayat, teknoloji ve sevdiğim konular hakkında düşüncelerim ve deneyimlerim.
              </p>
              <Button asChild variant="outline">
                <Link to="/blog">
                  Yazıları Keşfet <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            {/* Fotoğraflar */}
            <div className="bg-white dark:bg-slate-800 rounded-lg p-8 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-emerald-200 dark:group-hover:bg-emerald-800/50 transition-colors">
                <Camera className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Fotoğraf Galerisi</h3>
              <p className="text-slate-600 dark:text-slate-300 mb-6">
                Objektifimden yansıyan kareler, seyahatlerim ve özel anlardan kesitler.
              </p>
              <Button asChild variant="outline">
                <Link to="/fotograflar">
                  Fotoğrafları Gör <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            {/* Kitaplar */}
            <div className="bg-white dark:bg-slate-800 rounded-lg p-8 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-amber-200 dark:group-hover:bg-amber-800/50 transition-colors">
                <BookOpen className="h-8 w-8 text-amber-600 dark:text-amber-400" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Kitap İncelemeleri</h3>
              <p className="text-slate-600 dark:text-slate-300 mb-6">
                Okuduğum ve etkilendiğim kitaplar üzerine düşüncelerim ve tavsiyelerim.
              </p>
              <Button asChild variant="outline">
                <Link to="/kitaplar">
                  İncelemeleri Oku <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      {/* Son Paylaşımlar */}
      <section className="py-20 px-6 bg-white dark:bg-slate-950">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16 text-slate-800 dark:text-white">
            Son Paylaşımlarım
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Blog Yazısı */}
            <div className="bg-slate-50 dark:bg-slate-900 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow h-full flex flex-col">
              <img 
                src="https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/55d9316d-0bcf-4943-af21-0884cd7ede21.jpg" 
                alt="Blog görseli" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6 flex flex-col flex-grow">
                <span className="text-violet-600 dark:text-violet-400 text-sm font-medium mb-2">
                  Doğa
                </span>
                <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">
                  Doğanın Sesini Dinlemek
                </h3>
                <p className="text-slate-600 dark:text-slate-300 mb-6 flex-grow">
                  Şehir hayatının karmaşasından uzaklaşıp doğanın sunduğu huzuru keşfetmenin önemi...
                </p>
                <Button asChild variant="outline" className="self-start">
                  <Link to="/blog/1">
                    Devamını Oku
                  </Link>
                </Button>
              </div>
            </div>
            
            {/* Fotoğraf */}
            <div className="bg-slate-50 dark:bg-slate-900 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow h-full flex flex-col">
              <img 
                src="https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/de2e75e0-7562-4d6a-9d6a-73a8a80d1c9b.jpg" 
                alt="Fotoğraf görseli" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6 flex flex-col flex-grow">
                <span className="text-emerald-600 dark:text-emerald-400 text-sm font-medium mb-2">
                  Fotoğraf
                </span>
                <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">
                  Seyahetlerimde yada Sokakta Yakaladığım Kareler
                </h3>
                <p className="text-slate-600 dark:text-slate-300 mb-6 flex-grow">
                  Farklı mevsimlerde ve farklı lokasyonlarda zamanı durduğum anlar...
                </p>
                <Button asChild variant="outline" className="self-start">
                  <Link to="/fotograflar">
                    Koleksiyonu Gör
                  </Link>
                </Button>
              </div>
            </div>
            
            {/* Kitap */}
            <div className="bg-slate-50 dark:bg-slate-900 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow h-full flex flex-col">
              <img 
                src="https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/8e1ccf96-3050-4eff-a43d-19df33dbbcd4.jpg" 
                alt="Kitap görseli" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6 flex flex-col flex-grow">
                <span className="text-amber-600 dark:text-amber-400 text-sm font-medium mb-2">
                  Kitap
                </span>
                <h3 className="text-xl font-bold mb-3 text-slate-800 dark:text-white">
                  Ayın Kitap Tavsiyeleri
                </h3>
                <p className="text-slate-600 dark:text-slate-300 mb-6 flex-grow">
             Okuduğum kitaplara dair notlarım...
                </p>
                <Button asChild variant="outline" className="self-start">
                  <Link to="/kitaplar">
                    Tavsiyeleri Gör
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Project Adakale */}
      <ProjectAdakale />
    </div>
  );
};

export default Home;
