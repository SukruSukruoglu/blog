/**
 * Fotoğraf galerisi sayfası bileşeni - Kullanıcının fotoğraflarını sergiler ve yorum sistemi içerir
 */
import { FC, useState } from 'react';
import { X, ZoomIn, Download, Heart, Share2, Edit3, MessageCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import CommentSystem from '../components/CommentSystem';

// Fotoğraf verisi için arayüz
interface Photo {
  id: number;
  title: string;
  description: string;
  src: string;
  category: string;
  date: string;
  likes: number;
  isEditable?: boolean;
}

const Photos: FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [editingPhoto, setEditingPhoto] = useState<Photo | null>(null);
  const [showComments, setShowComments] = useState(false);

  // Örnek fotoğraf kategorileri
  const categories = ['Manzara', 'Şehir', 'Portre', 'Doğa', 'Mimari', 'Seyahat'];

  // Örnek fotoğraf verileri
  const [photos, setPhotos] = useState<Photo[]>([
    {
      id: 1,
      title: 'İstanbul Boğazı Gün Batımı',
      description: 'Gün batımında İstanbul Boğazının muhteşem manzarası. Bu fotoğrafı Çamlıca Tepesinden çektim.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/c26e9dc4-466e-4a32-8cf3-28b69fc637ff.jpg',
      category: 'Şehir',
      date: '15 Mayıs 2025',
      likes: 24,
      isEditable: true
    },
    {
      id: 2,
      title: 'Kapadokya Sıcak Hava Balonları',
      description: 'Kapadokya\'da gün doğumunda gökyüzünü süsleyen renkli sıcak hava balonları.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/8da8406a-94a9-47be-902c-a7a340d11adc.jpg',
      category: 'Seyahat',
      date: '10 Nisan 2025',
      likes: 32,
      isEditable: true
    },
    {
      id: 3,
      title: 'Doğal Köy Manzarası',
      description: 'Kuzey Ege\'de saklı kalmış bir köy evinin önünden harika manzara.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/335e5ef1-e642-42f5-91c9-b52560224c23.jpg',
      category: 'Manzara',
      date: '5 Mart 2025',
      likes: 18,
      isEditable: true
    },
    {
      id: 4,
      title: 'Tarihi İstanbul Sokakları',
      description: 'Balat\'taki renkli tarihi evlerin bulunduğu nostaljik sokaklar.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/7887e731-e044-4f22-bcdb-3f28bf69f219.jpg',
      category: 'Şehir',
      date: '20 Şubat 2025',
      likes: 27,
      isEditable: true
    },
    {
      id: 5,
      title: 'Kelebekler Vadisi Panorama',
      description: 'Fethiye\'deki ünlü Kelebekler Vadisi\'nden büyüleyici doğa manzarası.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/8570b77f-51d3-495c-bb31-df7538506baa.jpg',
      category: 'Doğa',
      date: '15 Ocak 2025',
      likes: 41,
      isEditable: true
    },
    {
      id: 6,
      title: 'Osmanlı Mimari Şaheseri',
      description: 'Osmanlı döneminden kalma tarihi bir caminin etkileyici kubbesi ve detayları.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/bfa780f3-6c8a-4ced-a49f-7e0df1fd85cb.jpg',
      category: 'Mimari',
      date: '10 Aralık 2024',
      likes: 22,
      isEditable: true
    },
    {
      id: 7,
      title: 'Yaşlı Amcanın Portresi',
      description: 'Yerel bir pazarda çalışan tecrübeli bir amcanın karakterli portresi.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/d962b873-87aa-4b0c-88d6-01e6b8205913.jpg',
      category: 'Portre',
      date: '5 Kasım 2024',
      likes: 35,
      isEditable: true
    },
    {
      id: 8,
      title: 'Galata Kulesi ve İstanbul',
      description: 'İstanbul\'un simgesi Galata Kulesi ve çevresindeki muhteşem şehir manzarası.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/039c8fbe-da02-4868-8910-f97ffa30ac69.jpg',
      category: 'Mimari',
      date: '20 Ekim 2024',
      likes: 29,
      isEditable: true
    },
    {
      id: 9,
      title: 'Ege Denizi Kıyısı',
      description: 'Ege denizinin berrak sularının kıyıya vurduğu turkuaz renkli sahil.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/949e4116-3371-4a6b-a3a3-27b7d66d3926.jpg',
      category: 'Manzara',
      date: '15 Eylül 2024',
      likes: 33,
      isEditable: true
    },
    {
      id: 10,
      title: 'Karadeniz Çay Bahçeleri',
      description: 'Karadeniz\'in yeşil yamaçlarındaki düzenli çay tarlaları ve doğal güzellik.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/d82c8d93-e63b-47b8-a7ac-48120124ea73.jpg',
      category: 'Doğa',
      date: '10 Ağustos 2024',
      likes: 26,
      isEditable: true
    },
    {
      id: 11,
      title: 'Mutlu Çocuk Gülümsemesi',
      description: 'Sokakta oynayan neşeli bir çocuğun içten gülümsemesi.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/75fb1d71-3772-485b-85bc-4d84ccd5c037.jpg',
      category: 'Portre',
      date: '5 Temmuz 2024',
      likes: 45,
      isEditable: true
    },
    {
      id: 12,
      title: 'Efes Antik Kenti',
      description: 'Tarihi Efes antik kentinden etkileyici kalıntılar ve mimari detaylar.',
      src: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/b285da5b-f48d-42f7-bbe5-d3f5ecb7b922.jpg',
      category: 'Seyahat',
      date: '1 Temmuz 2024',
      likes: 38,
      isEditable: true
    }
  ]);

  // Filtrelenmiş fotoğraflar
  const filteredPhotos = selectedCategory 
    ? photos.filter(photo => photo.category === selectedCategory) 
    : photos;

  // Fotoğraf detayını açma
  const openPhotoDetail = (photo: Photo) => {
    setSelectedPhoto(photo);
    setShowComments(false);
    document.body.style.overflow = 'hidden';
  };

  // Fotoğraf detayını kapatma
  const closePhotoDetail = () => {
    setSelectedPhoto(null);
    setEditingPhoto(null);
    setShowComments(false);
    document.body.style.overflow = 'auto';
  };

  // Fotoğraf düzenleme
  const startEditing = (photo: Photo) => {
    setEditingPhoto({ ...photo });
  };

  const saveEdit = () => {
    if (editingPhoto) {
      setPhotos(photos.map(photo => 
        photo.id === editingPhoto.id ? editingPhoto : photo
      ));
      if (selectedPhoto && selectedPhoto.id === editingPhoto.id) {
        setSelectedPhoto(editingPhoto);
      }
      setEditingPhoto(null);
    }
  };

  const cancelEdit = () => {
    setEditingPhoto(null);
  };

  // Fotoğraf beğenme
  const likePhoto = (photoId: number) => {
    setPhotos(photos.map(photo => 
      photo.id === photoId 
        ? { ...photo, likes: photo.likes + 1 }
        : photo
    ));
    if (selectedPhoto && selectedPhoto.id === photoId) {
      setSelectedPhoto({ ...selectedPhoto, likes: selectedPhoto.likes + 1 });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-merriweather">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-700 text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">Fotoğraf Galerisi</h1>
          <p className="text-xl text-purple-100 max-w-3xl">
            Gezilerimde ve özel anlarda çektiğim en güzel fotoğrafları sizlerle paylaşıyorum.
          </p>
        </div>
      </div>

      {/* Kategori Filtreleri */}
      <div className="bg-white dark:bg-slate-900 shadow-md py-4 px-6 sticky top-16 z-30">
        <div className="max-w-7xl mx-auto flex flex-wrap gap-2 justify-center">
          <Button 
            variant={selectedCategory === null ? "default" : "outline"}
            onClick={() => setSelectedCategory(null)}
          >
            Tümü ({photos.length})
          </Button>
          
          {categories.map(category => {
            const count = photos.filter(photo => photo.category === category).length;
            return (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
              >
                {category} ({count})
              </Button>
            );
          })}
        </div>
      </div>

      {/* Fotoğraf Galerisi */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredPhotos.map(photo => (
              <div 
                key={photo.id} 
                className="aspect-square overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer relative group bg-white dark:bg-slate-800"
                onClick={() => openPhotoDetail(photo)}
              >
                <img 
                  src={photo.src} 
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                  <h3 className="text-white font-medium text-lg mb-1">{photo.title}</h3>
                  <div className="flex items-center justify-between">
                    <p className="text-white/80 text-sm">{photo.category}</p>
                    <div className="flex items-center text-white/80 text-sm">
                      <Heart className="h-4 w-4 mr-1" />
                      {photo.likes}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fotoğraf Detay Modalı */}
      {selectedPhoto && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="absolute top-4 right-4 z-10">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={closePhotoDetail}
              className="text-white hover:bg-white/20"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>
          
          <div className="w-full max-w-6xl bg-white dark:bg-slate-800 rounded-lg overflow-hidden shadow-2xl flex flex-col lg:flex-row max-h-[95vh]">
            <div className="lg:w-2/3 relative bg-black flex items-center justify-center">
              <img 
                src={selectedPhoto.src} 
                alt={selectedPhoto.title}
                className="max-h-[60vh] lg:max-h-[95vh] w-full object-contain"
              />
            </div>
            
            <div className="lg:w-1/3 flex flex-col">
              <div className="p-6 flex-1 overflow-y-auto">
                {editingPhoto && editingPhoto.id === selectedPhoto.id ? (
                  // Düzenleme Modu
                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
                      Fotoğraf Bilgilerini Düzenle
                    </h3>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        Fotoğraf Başlığı
                      </label>
                      <Input
                        value={editingPhoto.title}
                        onChange={(e) => setEditingPhoto({ ...editingPhoto, title: e.target.value })}
                        placeholder="Fotoğraf başlığını girin"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        Açıklama
                      </label>
                      <Textarea
                        value={editingPhoto.description}
                        onChange={(e) => setEditingPhoto({ ...editingPhoto, description: e.target.value })}
                        placeholder="Fotoğraf açıklamasını girin"
                        className="min-h-[100px]"
                      />
                    </div>
                    
                    <div className="flex gap-2">
                      <Button onClick={saveEdit} className="flex-1">
                        Kaydet
                      </Button>
                      <Button variant="outline" onClick={cancelEdit} className="flex-1">
                        İptal
                      </Button>
                    </div>
                  </div>
                ) : (
                  // Normal Görünüm
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                        {selectedPhoto.title}
                      </h2>
                      {selectedPhoto.isEditable && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => startEditing(selectedPhoto)}
                        >
                          <Edit3 className="h-4 w-4 mr-1" />
                          Düzenle
                        </Button>
                      )}
                    </div>
                    
                    <div className="flex items-center mb-4">
                      <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300 text-xs font-medium px-2.5 py-1 rounded mr-3">
                        {selectedPhoto.category}
                      </span>
                      <span className="text-slate-500 dark:text-slate-400 text-sm">
                        {selectedPhoto.date}
                      </span>
                    </div>
                    
                    <p className="text-slate-700 dark:text-slate-300 mb-6">
                      {selectedPhoto.description}
                    </p>
                    
                    <div className="flex gap-2 mb-6">
                      <Button 
                        className="flex-1"
                        onClick={() => likePhoto(selectedPhoto.id)}
                      >
                        <Heart className="h-4 w-4 mr-2" /> 
                        Beğen ({selectedPhoto.likes})
                      </Button>
                      <Button variant="outline" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <Share2 className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <ZoomIn className="h-4 w-4" />
                      </Button>
                    </div>

                    <Button 
                      onClick={() => setShowComments(!showComments)}
                      variant="outline" 
                      className="w-full mb-4"
                    >
                      <MessageCircle className="h-4 w-4 mr-2" />
                      {showComments ? 'Yorumları Gizle' : 'Yorumları Göster'}
                    </Button>
                  </>
                )}
              </div>
              
              {/* Yorum Sistemi */}
              {showComments && !editingPhoto && (
                <div className="border-t border-slate-200 dark:border-slate-700 p-6 max-h-[40vh] overflow-y-auto">
                  <CommentSystem 
                    contentId={selectedPhoto.id.toString()} 
                    contentType="photo"
                    title={selectedPhoto.title}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Photos;