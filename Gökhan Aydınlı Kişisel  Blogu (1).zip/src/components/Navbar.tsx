
/**
 * Navbar bileşeni - Tüm sayfalarda görüntülenen ana navigasyon
 */
import { FC, useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router';
import { Menu, X, Sun, Moon, BookOpen } from 'lucide-react';
import { Button } from './ui/button';

const Navbar: FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const location = useLocation();

  // Sayfa değiştiğinde mobil menüyü kapat
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  // Dark mode toggle
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const routes = [
    { name: 'Ana Sayfa', path: '/' },
    { name: 'Blog', path: '/blog' },
    { name: 'Fotoğraflar', path: '/fotograflar' },
    { name: 'Kitaplar', path: '/kitaplar' },
    { name: 'Hakkımda', path: '/hakkimda' },
    { name: 'Admin', path: '/admin' },
  ];

  return (
    <nav className="bg-white dark:bg-slate-900 shadow-md sticky top-0 z-50 font-merriweather">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            <NavLink to="/" className="flex items-center">
              <BookOpen className="h-8 w-8 text-violet-600 dark:text-violet-400 mr-2" />
              <span className="text-xl font-bold text-slate-900 dark:text-white">Gökhan Aydınlı</span>
            </NavLink>
          </div>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-1">
            {routes.map((route) => (
              <NavLink
                key={route.path}
                to={route.path}
                className={({ isActive }) => 
                  `px-3 py-2 rounded-md text-sm font-medium ${
                    isActive 
                      ? 'bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300' 
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`
                }
              >
                {route.name}
              </NavLink>
            ))}
            
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleDarkMode}
              className="ml-2"
              aria-label={isDarkMode ? "Açık tema" : "Koyu tema"}
            >
              {isDarkMode ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : (
                <Moon className="h-5 w-5 text-slate-700" />
              )}
            </Button>
          </div>
          
          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleDarkMode}
              className="mr-2"
              aria-label={isDarkMode ? "Açık tema" : "Koyu tema"}
            >
              {isDarkMode ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : (
                <Moon className="h-5 w-5 text-slate-700" />
              )}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Ana menü"
            >
              {isOpen ? (
                <X className="h-6 w-6 text-slate-700 dark:text-white" />
              ) : (
                <Menu className="h-6 w-6 text-slate-700 dark:text-white" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white dark:bg-slate-900 shadow-lg">
            {routes.map((route) => (
              <NavLink
                key={route.path}
                to={route.path}
                className={({ isActive }) => 
                  `block px-3 py-2 rounded-md text-base font-medium ${
                    isActive 
                      ? 'bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300' 
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`
                }
              >
                {route.name}
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
