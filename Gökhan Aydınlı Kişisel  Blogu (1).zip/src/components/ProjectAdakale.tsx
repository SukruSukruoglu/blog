/**
 * Project Adakale bileşeni - Sanat, tasarım, sürdürebilirlik ve permakültür odaklı kapsamlı proje bölümü
 */
import { FC } from 'react';
import { Leaf, Users, Palette, ArrowRight, MapPin, Calendar, BookOpen, Sprout, Home, TreePine, Hammer, GraduationCap, FlowerIcon } from 'lucide-react';
import { Button } from './ui/button';
import { useProjectStore } from '../stores/projectStore';

const ProjectAdakale: FC = () => {
  const { getPublishedProjects } = useProjectStore();
  const publishedProjects = getPublishedProjects();

  const temelBilesenler = [
    {
      title: 'Topluluk ve Paylaşım',
      description: 'İnsanları bir araya getiren, ortak değerler etrafında bütünleşen topluluk alanı. Karşılıklı öğrenme ve dayanışma kültürü.',
      icon: Users,
      color: 'from-blue-600 to-indigo-700',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20',
      iconColor: 'text-blue-600 dark:text-blue-400'
    },
    {
      title: 'Sürdürülebilir Yaşam Pratikleri',
      description: 'Geleneksel tarım ürünleri modern ekolojik ürünlerle birleştirici model. Ata tohumları ve permakültür uygulamaları.',
      icon: Sprout,
      color: 'from-green-600 to-emerald-700',
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      iconColor: 'text-green-600 dark:text-green-400'
    },
    {
      title: 'Sanat ve Doğa Entegrasyonu',
      description: 'Doğal yöntemlerle sanat üretimi, ekolojik sanat atölyeleri, gastronomi çalışmaları ve doğal gıda işleme teknikleri.',
      icon: Palette,
      color: 'from-purple-600 to-indigo-700',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20',
      iconColor: 'text-purple-600 dark:text-purple-400'
    }
  ];

  const projeAlanlari = [
    {
      title: 'Tarım ve Üretim',
      items: [
        'Geleneksel tarım teknikleri',
        'Sera faaliyetleri ve organik tarım',
        'Ata tohumları bankacılığı',
        'Kaliteli ve ari tohum üretimi'
      ],
      icon: TreePine,
      color: 'text-green-700 dark:text-green-400'
    },
    {
      title: 'Eğitim ve Paylaşım',
      items: [
        'Sürdürülebilir yaşam atölyeleri',
        'Permakültür eğitimleri',
        'Sanat ve tasarım çalışmaları',
        'Yerel etkinlikler ve bilgi paylaşımı'
      ],
      icon: GraduationCap,
      color: 'text-amber-700 dark:text-amber-400'
    },
    {
      title: 'Sanat Projeleri',
      items: [
        'Doğal malzemelerle sanat (toprak saksı, seramik)',
        'Marangozluk ve yerel ev inşa teknikleri',
        'Permakültür bahçeleri ve kompost üretimi',
        'Topluluk sanat fuarları'
      ],
      icon: Hammer,
      color: 'text-purple-700 dark:text-purple-400'
    }
  ];

  return (
    <section className="py-20 px-6 bg-gradient-to-br from-green-50 via-amber-50 to-emerald-50 dark:from-green-950/20 dark:via-amber-950/20 dark:to-emerald-950/20">
      <div className="max-w-7xl mx-auto">
        
        {/* Hero Section */}
        <div className="text-center mb-20">
          <div className="relative mb-12">
            <div className="absolute inset-0 bg-gradient-to-r from-green-600/20 to-amber-600/20 rounded-3xl blur-3xl"></div>
            <div className="relative bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm rounded-3xl p-12 shadow-2xl border border-green-100 dark:border-green-800">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-green-600 to-emerald-700 rounded-full flex items-center justify-center mr-4">
                  <Home className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-5xl font-bold bg-gradient-to-r from-green-700 via-amber-600 to-emerald-700 bg-clip-text text-transparent">
                  Adakale Project
                </h2>
              </div>
              
              <p className="text-2xl text-slate-700 dark:text-slate-300 mb-8 max-w-5xl mx-auto leading-relaxed font-medium">
                Sanat, Tasarım, Sürdürülebilirlik ve Permakültür Üzerine Kurgulanmış Bütüncül Ekolojik Yaşam Projesi
              </p>
              
              <div className="bg-gradient-to-r from-emerald-50 to-green-50 dark:from-emerald-900/20 dark:to-green-900/20 rounded-2xl p-6 mb-8">
                <p className="text-lg text-green-800 dark:text-green-300 italic font-medium">
                  "Bir Gayrimenkul'den filizlenen, Birlikte büyümek, birlikte yaşamak, doğayla uyum içinde var olmak felsefesidir"
                </p>
              </div>
              
              {/* Hero Image */}
              <div className="relative mb-8 overflow-hidden rounded-2xl shadow-2xl">
                <img 
                  src="https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/85d67b4a-ed7e-43df-869b-5d8e6a5a9bb5.jpg"
                  alt="Sürdürebilir topluluk bahçesi ve permakültür uygulamaları"
                  className="w-full h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <div className="flex items-center justify-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    <span className="text-lg font-medium">Bütüncül Yaşam Modeli Merkezi</span>
                  </div>
                </div>
              </div>
              
              <Button size="lg" className="bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-700 hover:to-emerald-800 text-white px-10 py-4 text-lg font-semibold">
                <BookOpen className="h-5 w-5 mr-2" />
                Projeyi Keşfet
              </Button>
            </div>
          </div>
        </div>

        {/* Proje Felsefesi */}
        <div className="mb-20">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 lg:p-12 border border-slate-100 dark:border-slate-700">
            <div className="flex items-center mb-8">
              <FlowerIcon className="h-8 w-8 text-emerald-600 mr-3" />
              <h3 className="text-3xl font-bold text-slate-800 dark:text-white">Proje Felsefesi</h3>
            </div>
            
            <div className="prose prose-lg max-w-none text-slate-700 dark:text-slate-200">
              <p className="text-xl leading-relaxed mb-8 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 p-6 rounded-xl">
                Adakale Projesi, <strong>sanat, tasarım ve sürdürülebilirlik</strong> üzerine kurgulanmış <em>bütüncül bir yaşam modelidir</em>. 
                Doğayla uyumlu, toplumsal dayanışmayı merkeze alan ve ekolojik dengeyi gözeten bir yaklaşım benimsemektedir.
              </p>
            </div>
          </div>
        </div>

        {/* Temel Bileşenler */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold text-center mb-12 text-slate-800 dark:text-white">
            Temel Bileşenler
          </h3>
          
          <div className="grid md:grid-cols-3 gap-8">
            {temelBilesenler.map((bilesen, index) => (
              <div key={index} className="group">
                <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-8 h-full border border-slate-100 dark:border-slate-700">
                  <div className={`w-16 h-16 ${bilesen.bgColor} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <bilesen.icon className={`h-8 w-8 ${bilesen.iconColor}`} />
                  </div>
                  
                  <h4 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">
                    {bilesen.title}
                  </h4>
                  
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {bilesen.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Proje Alanları */}
        <div className="mb-20">
          <div className="bg-gradient-to-r from-slate-50 to-green-50 dark:from-slate-800 dark:to-green-900/20 rounded-2xl p-8 lg:p-12">
            <h3 className="text-3xl font-bold text-center mb-12 text-slate-800 dark:text-white">
              Proje Alanları
            </h3>
            
            <div className="grid lg:grid-cols-3 gap-8">
              {projeAlanlari.map((alan, index) => (
                <div key={index} className="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-lg border border-slate-100 dark:border-slate-700">
                  <div className="flex items-center mb-6">
                    <alan.icon className={`h-8 w-8 ${alan.color} mr-3`} />
                    <h4 className="text-xl font-bold text-slate-800 dark:text-white">
                      {alan.title}
                    </h4>
                  </div>
                  
                  <ul className="space-y-3">
                    {alan.items.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-start">
                        <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <span className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                          {item}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Vizyonumuz */}
        <div className="mb-20">
          <div className="bg-gradient-to-r from-green-600 to-emerald-700 rounded-3xl p-12 text-white">
            <div className="text-center">
              <h3 className="text-3xl font-bold mb-8">Vizyonumuz</h3>
              <div className="max-w-4xl mx-auto">
                <p className="text-xl leading-relaxed mb-6 opacity-95">
                  Adakale Projesi, <strong>insan-doğa ilişkilerini yeniden düzenlenmiş</strong>, 
                  sürdürülebilir, üretken ve yaratıcı bir yaşam modeli sunmayı amaçlamaktadır.
                </p>
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
                  <p className="text-lg italic">
                    Proje, belirli bir hedefe ulaşmak için planlanmış ve uygulanan işler, 
                    araştırmalar veya etkinlikler bütünüdür.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Proje İçerikleri Galerisi */}
        {publishedProjects.length > 0 && (
          <div className="mb-20">
            <h3 className="text-3xl font-bold text-center mb-12 text-slate-800 dark:text-white">
              Proje Galerisi ve Uygulamalar
            </h3>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {publishedProjects.map((project) => (
                <div key={project.id} className="group">
                  <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-slate-100 dark:border-slate-700">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={project.imageUrl} 
                        alt={project.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="absolute bottom-4 left-4 right-4">
                          <Button size="sm" className="w-full bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30">
                            <Calendar className="h-4 w-4 mr-2" />
                            Detayları Gör
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <h4 className="text-xl font-bold mb-3 text-slate-800 dark:text-white group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
                        {project.title}
                      </h4>
                      <p className="text-slate-600 dark:text-slate-300 mb-4 line-clamp-3">
                        {project.description}
                      </p>
                      <div className="flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
                        <span>{new Date(project.updatedAt).toLocaleDateString('tr-TR')}</span>
                        <span className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 px-3 py-1 rounded-full text-xs font-medium">
                          Aktif Proje
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-br from-green-600 via-emerald-600 to-teal-700 rounded-3xl p-12 text-white shadow-2xl">
          <div className="flex items-center justify-center mb-6">
            <Leaf className="h-10 w-10 mr-3" />
            <h3 className="text-4xl font-bold">
              Bütüncül Yaşama Katılın
            </h3>
          </div>
          <p className="text-xl mb-8 max-w-4xl mx-auto opacity-90 leading-relaxed">
            Doğa ile uyum içinde, sanatla zenginleşen, permakültür ile beslenen ve topluluk ruhuyla güçlenen 
            bir yaşam tarzının parçası olun. Bilgi ve tecrübe paylaşımında buluşalım.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" variant="secondary" className="bg-white text-green-700 hover:bg-green-50 px-8 py-3 text-lg font-semibold">
              <ArrowRight className="h-5 w-5 mr-2" />
              Proje Detayları
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-3 text-lg font-semibold">
              <Users className="h-5 w-5 mr-2" />
              Topluluğa Katıl
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectAdakale;