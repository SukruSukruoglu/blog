/**
 * Yorum sistemi bileşeni - Kullanıcıların yorum yapabilmesi için form ve yorum listesi
 */
import { FC, useState } from 'react';
import { MessageCircle, User, Mail, Send, Heart, Reply } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';

interface Comment {
  id: number;
  name: string;
  email: string;
  message: string;
  date: string;
  likes: number;
}

interface CommentSystemProps {
  contentId: string;
  contentType: 'blog' | 'photo' | 'book';
  title?: string;
}

const CommentSystem: FC<CommentSystemProps> = ({ contentId, contentType, title }) => {
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      name: 'Ahmet Yılmaz',
      email: 'ahmet@example.com',
      message: 'Harika bir paylaşım! Çok beğendim ve faydalı bilgiler aldım.',
      date: '2 gün önce',
      likes: 5
    },
    {
      id: 2,
      name: 'Fatma Demir',
      email: 'fatma@example.com',
      message: 'Bu konuda daha fazla bilgi paylaşmanızı bekliyorum. Teşekkürler!',
      date: '1 hafta önce',
      likes: 3
    }
  ]);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Yeni yorum ekleme (gerçek uygulamada API çağrısı yapılacak)
    const newComment: Comment = {
      id: comments.length + 1,
      name: formData.name,
      email: formData.email,
      message: formData.message,
      date: 'Az önce',
      likes: 0
    };

    setComments([newComment, ...comments]);
    setFormData({ name: '', email: '', message: '' });
    setIsSubmitting(false);
  };

  const handleLike = (commentId: number) => {
    setComments(comments.map(comment => 
      comment.id === commentId 
        ? { ...comment, likes: comment.likes + 1 }
        : comment
    ));
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-md">
      <div className="flex items-center mb-6">
        <MessageCircle className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-2" />
        <h3 className="text-xl font-bold text-slate-900 dark:text-white">
          Yorumlar ({comments.length})
        </h3>
      </div>

      {/* Yorum Formu */}
      <form onSubmit={handleSubmit} className="mb-8 p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
        <h4 className="text-lg font-medium text-slate-900 dark:text-white mb-4">
          Yorum Yap
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Adınız Soyadınız"
              className="pl-10"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>
          
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              type="email"
              placeholder="Email adresiniz"
              className="pl-10"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>
        </div>
        
        <Textarea
          placeholder="Yorumunuzu yazın..."
          className="mb-4 min-h-[100px]"
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          required
        />
        
        <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
          <Send className="h-4 w-4 mr-2" />
          {isSubmitting ? 'Gönderiliyor...' : 'Yorum Gönder'}
        </Button>
      </form>

      {/* Yorumlar Listesi */}
      <div className="space-y-6">
        {comments.map((comment) => (
          <div key={comment.id} className="border-b border-slate-200 dark:border-slate-600 pb-6 last:border-b-0">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium">
                {comment.name.charAt(0).toUpperCase()}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <h5 className="font-medium text-slate-900 dark:text-white mr-2">
                    {comment.name}
                  </h5>
                  <span className="text-sm text-slate-500 dark:text-slate-400">
                    {comment.date}
                  </span>
                </div>
                
                <p className="text-slate-700 dark:text-slate-300 mb-3">
                  {comment.message}
                </p>
                
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLike(comment.id)}
                    className="text-slate-500 hover:text-red-500"
                  >
                    <Heart className="h-4 w-4 mr-1" />
                    {comment.likes}
                  </Button>
                  
                  <Button variant="ghost" size="sm" className="text-slate-500">
                    <Reply className="h-4 w-4 mr-1" />
                    Yanıtla
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentSystem;