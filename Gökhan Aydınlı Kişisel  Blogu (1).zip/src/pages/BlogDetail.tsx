/**
 * Blog detay sayfası bileşeni - Tek bir blog yazısının tam içeriğini gösterir ve yorum sistemi içerir
 */
import { FC } from 'react';
import { useParams, Link } from 'react-router';
import { ChevronLeft, Clock, Tag, Share2, Bookmark, ThumbsUp, MessageCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import CommentSystem from '../components/CommentSystem';

interface BlogPost {
  id: number;
  title: string;
  content: string;
  coverImage: string;
  date: string;
  category: string;
  readTime: string;
  tags: string[];
  author: {
    name: string;
    avatar: string;
  };
}

const BlogDetail: FC = () => {
  const { id } = useParams<{ id: string }>();
  
  // Örnek blog yazısı verisi (Normalde API'den alınırdı)
  const post: BlogPost = {
    id: parseInt(id || '1'),
    title: 'İstanbul\'da Gün Batımı Fotoğrafçılığı',
    content: `
      <p>İstanbul, gün batımı fotoğrafçılığı için dünyanın en güzel şehirlerinden biridir. Boğaz'ın eşsiz manzarası, tarihi yarımadanın silüeti ve şehrin tepelerinden görünen panoramik görüntüler, gün batımı fotoğrafları için mükemmel fırsatlar sunar.</p>
      
      <h2>En İyi Lokasyonlar</h2>
      
      <p>İstanbul'da gün batımı fotoğrafı çekmek için en iyi yerlerden bazıları şunlardır:</p>
      
      <ul>
        <li>
          <strong>Çamlıca Tepesi:</strong> Şehrin Anadolu yakasında bulunan bu tepe, tüm İstanbul'un panoramik manzarasını sunar. Özellikle günbatımında, güneş Avrupa yakasının arkasında batarken oluşan silüet muhteşemdir.
        </li>
        <li>
          <strong>Pierre Loti Tepesi:</strong> Eyüp'te bulunan bu tarihi tepe, Haliç'in muhteşem manzarasını sunar. Tarihi kahvehanede oturup, güneşin Haliç'in üzerinde batışını izleyebilirsiniz.
        </li>
        <li>
          <strong>Galata Kulesi:</strong> İstanbul'un en ikonik yapılarından biri olan Galata Kulesi, Haliç ve tarihi yarımadanın muhteşem manzarasını sunar.
        </li>
        <li>
          <strong>Ortaköy Camii:</strong> Boğaz'ın yanı başındaki bu camii, özellikle arkasında görünen Boğaz Köprüsü ile birlikte günbatımında harika kareler sunuyor.
        </li>
      </ul>
      
      <h2>Ekipman Önerileri</h2>
      
      <p>Gün batımı fotoğrafçılığı için bazı temel ekipman önerileri şunlardır:</p>
      
      <ul>
        <li>
          <strong>Tripod:</strong> Gün batımında ışık azaldığı için uzun pozlama yapmanız gerekebilir. Bu yüzden sağlam bir tripod şart.
        </li>
        <li>
          <strong>ND Filtreler:</strong> Nötr yoğunluk filtreleri, aşırı parlak güneş ışığını dengelemek için kullanışlıdır.
        </li>
        <li>
          <strong>Geniş Açı Lens:</strong> Manzara fotoğrafçılığı için geniş açı lensler idealdir. 16-35mm aralığında bir lens önerilir.
        </li>
      </ul>
      
      <h2>Teknik İpuçları</h2>
      
      <p>İyi bir gün batımı fotoğrafı çekmek için bazı teknik ipuçları:</p>
      
      <ol>
        <li>
          <strong>Düşük ISO:</strong> Gürültüyü minimuma indirmek için mümkün olan en düşük ISO değerini kullanın.
        </li>
        <li>
          <strong>Doğru Pozlama:</strong> Histogram'ı kontrol edin ve genellikle gökyüzü için biraz düşük pozlama yapın.
        </li>
        <li>
          <strong>Doğru Zamanlama:</strong> Altın saat olarak bilinen güneş batımından yaklaşık 1 saat öncesinden başlayarak çekim yapın.
        </li>
        <li>
          <strong>Kompozisyon:</strong> Gökyüzü kadar önemli ön plan elemanları da dahil edin.
        </li>
      </ol>
      
      <p>İstanbul'da gün batımı fotoğrafçılığı, sabır ve doğru zamanlama gerektirir. Hava durumunu takip etmek, bulutlu günlerde daha dramatik renkler elde edebileceğinizi unutmamak önemlidir.</p>
      
      <p>Umarım bu ipuçları İstanbul'da muhteşem gün batımı fotoğrafları çekmenize yardımcı olur!</p>
    `,
    coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/8e7786a1-ea38-4ac7-a049-f60fe6dc02c0.jpg',
    date: '20 Haziran 2025',
    category: 'Fotoğrafçılık',
    readTime: '8 dakika',
    tags: ['İstanbul', 'Gün Batımı', 'Fotoğrafçılık', 'Manzara'],
    author: {
      name: 'Gökhan Aydınlı',
      avatar: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/49c66ad0-dce5-41b3-bd2f-965863b9eb9a.jpg'
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 font-merriweather">
      {/* Hero / Kapak */}
      <div className="relative h-[60vh]">
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-transparent z-10" />
        <img 
          src={post.coverImage} 
          alt={post.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-0 left-0 w-full p-6 z-20">
          <Button asChild variant="ghost" className="text-white hover:bg-white/20">
            <Link to="/blog">
              <ChevronLeft className="h-5 w-5 mr-1" /> Tüm Yazılar
            </Link>
          </Button>
        </div>
      </div>

      {/* İçerik */}
      <div className="max-w-4xl mx-auto -mt-16 relative z-20 px-6">
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-xl p-8 mb-12">
          <div className="flex items-center mb-6">
            <img 
              src={post.author.avatar} 
              alt={post.author.name}
              className="w-12 h-12 rounded-full object-cover mr-4"
            />
            <div>
              <p className="font-medium text-slate-900 dark:text-white">{post.author.name}</p>
              <div className="flex items-center text-sm text-slate-500 dark:text-slate-400">
                <Clock className="h-4 w-4 mr-1" />
                <span>{post.date} • {post.readTime} okuma</span>
              </div>
            </div>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-slate-900 dark:text-white">
            {post.title}
          </h1>
          
          <div className="flex flex-wrap gap-2 mb-8">
            <span className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 text-xs font-medium px-2.5 py-1 rounded">
              {post.category}
            </span>
            {post.tags.map(tag => (
              <div key={tag} className="flex items-center text-xs bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 px-2.5 py-1 rounded">
                <Tag className="h-3 w-3 mr-1" />
                {tag}
              </div>
            ))}
          </div>
          
          <div 
            className="prose prose-slate dark:prose-invert max-w-none mb-8 prose-headings:text-slate-900 dark:prose-headings:text-white prose-p:text-slate-700 dark:prose-p:text-slate-300 prose-li:text-slate-700 dark:prose-li:text-slate-300 prose-strong:text-slate-900 dark:prose-strong:text-white"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
          
          <div className="border-t border-slate-200 dark:border-slate-700 pt-6 mt-8">
            <div className="flex flex-wrap justify-between items-center">
              <div className="flex gap-2 mb-4 md:mb-0">
                <Button>
                  <ThumbsUp className="h-4 w-4 mr-2" /> Beğen
                </Button>
                <Button variant="outline">
                  <Share2 className="h-4 w-4 mr-2" /> Paylaş
                </Button>
                <Button variant="outline">
                  <Bookmark className="h-4 w-4 mr-2" /> Kaydet
                </Button>
              </div>
              
              <div className="flex items-center text-sm text-slate-500 dark:text-slate-400">
                <MessageCircle className="h-4 w-4 mr-1" />
                <span>Bu yazıyı faydalı buldunuz mu?</span>
              </div>
            </div>
          </div>
        </div>

        {/* Yorum Sistemi */}
        <div className="mb-12">
          <CommentSystem 
            contentId={post.id.toString()} 
            contentType="blog"
            title={post.title}
          />
        </div>

        {/* İlgili Yazılar */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-slate-900 dark:text-white">
            İlgili Yazılar
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { id: 2, title: 'Makro Fotoğrafçılık: Başlangıç Rehberi', image: 'macro photography tips' },
              { id: 3, title: 'Fotoğraf Düzenlemede Işık ve Renk Yönetimi', image: 'photo editing lighting' },
              { id: 4, title: 'Sokak Fotoğrafçılığı İpuçları', image: 'street photography tips' }
            ].map((relatedPost) => (
              <Link 
                to={`/blog/${relatedPost.id}`}
                key={relatedPost.id}
                className="group bg-white dark:bg-slate-800 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="relative h-40 overflow-hidden">
                  <img 
                    src={`https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/6b36977a-35da-4183-900f-b1250ff6f21a.jpg`}
                    alt={relatedPost.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {relatedPost.title}
                  </h3>
                  <div className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    {new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogDetail;