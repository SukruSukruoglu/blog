<?php
/**
 * Data export script for migrating to MySQL
 */

require_once '../config/database.php';

class DataExporter {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * Export all data to JSON
     */
    public function exportAllData() {
        $data = array(
            'projects' => $this->exportProjects(),
            'blog_posts' => $this->exportBlogPosts(),
            'photos' => $this->exportPhotos(),
            'books' => $this->exportBooks(),
            'site_settings' => $this->exportSettings(),
            'export_date' => date('Y-m-d H:i:s')
        );
        
        return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    private function exportProjects() {
        $query = "SELECT * FROM projects ORDER BY order_index ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function exportBlogPosts() {
        $query = "SELECT * FROM blog_posts ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function exportPhotos() {
        $query = "SELECT * FROM photos ORDER BY order_index ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function exportBooks() {
        $query = "SELECT * FROM books ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function exportSettings() {
        $query = "SELECT * FROM site_settings";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Export data
$exporter = new DataExporter();
$jsonData = $exporter->exportAllData();

// Save to file
$filename = 'adakale_export_' . date('Y-m-d_H-i-s') . '.json';
file_put_contents($filename, $jsonData);

// Output for download
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="' . $filename . '"');
echo $jsonData;
?>
