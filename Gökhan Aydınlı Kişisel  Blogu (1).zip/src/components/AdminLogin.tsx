/**
 * Admin giriş bileşeni - Güvenli authentication form
 */
import { FC, useState, useEffect } from 'react';
import { Shield, Lock, User, AlertTriangle, Eye, EyeOff } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { useAuthStore } from '../stores/authStore';

interface AdminLoginProps {
  onLoginSuccess: () => void;
}

const AdminLogin: FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login, loginAttempts, lastAttempt } = useAuthStore();
  
  const MAX_ATTEMPTS = 5;
  const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 dakika

  const isLockedOut = loginAttempts >= MAX_ATTEMPTS && 
    (Date.now() - lastAttempt) < LOCKOUT_DURATION;

  const remainingLockoutTime = isLockedOut 
    ? Math.ceil((LOCKOUT_DURATION - (Date.now() - lastAttempt)) / 1000 / 60)
    : 0;

  useEffect(() => {
    if (isLockedOut) {
      setError(`Çok fazla hatalı giriş denemesi. ${remainingLockoutTime} dakika sonra tekrar deneyin.`);
    }
  }, [isLockedOut, remainingLockoutTime]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isLockedOut) {
      setError(`Hesap kilitli. ${remainingLockoutTime} dakika sonra tekrar deneyin.`);
      return;
    }

    setIsLoading(true);
    setError('');

    // Simüle edilmiş yükleme süresi (güvenlik için)
    await new Promise(resolve => setTimeout(resolve, 1000));

    const success = login(username, password);
    
    if (success) {
      setError('');
      onLoginSuccess();
    } else {
      setError(
        loginAttempts >= MAX_ATTEMPTS - 1
          ? 'Geçersiz bilgiler! Hesabınız kilitlenmiştir.'
          : `Geçersiz kullanıcı adı veya şifre! Kalan deneme: ${MAX_ATTEMPTS - loginAttempts - 1}`
      );
      setPassword('');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" />
      
      <Card className="w-full max-w-md relative z-10 shadow-2xl border-0 bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm">
        <CardHeader className="text-center pb-8">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full flex items-center justify-center">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900 dark:text-white">
            Admin Panel Girişi
          </CardTitle>
          <CardDescription className="text-slate-600 dark:text-slate-400">
            Yönetici paneline erişmek için giriş yapın
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="flex items-center p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0" />
                <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
              </div>
            )}

            <div className="space-y-4">
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Kullanıcı Adı"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-10 h-12"
                  disabled={isLoading || isLockedOut}
                  required
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Şifre"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10 h-12"
                  disabled={isLoading || isLockedOut}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  disabled={isLoading || isLockedOut}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
              disabled={isLoading || isLockedOut}
            >
              {isLoading ? (
                <div className="flex items-center">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Giriş Yapılıyor...
                </div>
              ) : (
                'Giriş Yap'
              )}
            </Button>

            {loginAttempts > 0 && !isLockedOut && (
              <div className="text-center">
                <p className="text-sm text-amber-600 dark:text-amber-400">
                  Hatalı giriş denemesi: {loginAttempts}/5
                </p>
              </div>
            )}
          </form>

          <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">
            <div className="text-center">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Güvenli Bağlantı • Session Timeout: 30dk
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminLogin;
