/**
 * React uygulamasındaki tüm verileri export eden utility fonksiyonları
 */

import { useProjectStore } from '../stores/projectStore';
import { useAuthStore } from '../stores/authStore';

/**
 * Tüm proje verilerini export et
 */
export const exportProjectData = () => {
  const { projects } = useProjectStore.getState();
  return projects;
};

/**
 * Sample blog posts data
 */
export const exportBlogData = () => {
  return [
    {
      id: 1,
      title: 'Sürdürülebilir Bahçecilik İlkeleri',
      slug: 'surdurulebilir-bahcecilik-ilkeleri',
      excerpt: 'Doğal yöntemlerle sağlıklı bahçecilik yapmanın temel ilkeleri',
      content: `
# Sürdürülebilir Bahçecilik İlkeleri

Adakale Project'te uyguladığımız sürdürülebilir bahçecilik yaklaşımı, doğal döngülere saygılı ve ekolojik dengeyi gözeten bir felsefe üzerine kuruludur.

## Temel İlkeler

### 1. Ata Tohumları Kullanımı
- Yerel ve geleneksel tohum çeşitlerinin korunması
- Tohum bankacılığı uygulamaları
- Genetik çeşitliliğin sürdürülmesi

### 2. Permakültür Yaklaşımı
- Doğal ekosistem modellemesi
- Companion planting (eşlikçi bitki) uygulamaları
- Su ve besin döngülerinin optimize edilmesi

### 3. Sıfır Atık Prensibi
- Kompost üretimi
- Geri dönüşüm sistemleri
- Doğal kaynak korunumu

## Uygulama Alanları

Projemizde bu ilkeleri çeşitli alanlarda hayata geçiriyoruz:
- Sebze bahçeleri
- Meyve ağaçları dikimi
- Aromatik bitki yetiştirimi
- Sera faaliyetleri
      `,
      category: 'Permakültür',
      tags: 'sürdürülebilirlik,bahçecilik,permakültür,ata tohumları',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/d91f1b4a-35a8-44ff-bb3b-b4d1ac29c455.jpg',
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 2,
      title: 'Geleneksel Tarım Teknikleri',
      slug: 'geleneksel-tarim-teknikleri',
      excerpt: 'Atalımızdan gelen tarım bilgisi ve modern uygulamaların buluşması',
      content: `
# Geleneksel Tarım Teknikleri

Adakale Project'te geleneksel bilgi ile modern ekolojik yaklaşımları birleştiriyoruz.

## Geleneksel Yöntemler

### Tohum Muhafazası
- Doğal kurutma teknikleri
- Uygun saklama koşulları
- Tohum canlılık testleri

### Doğal Gübre Üretimi
- Hayvan gübresi kompozisyonu
- Yeşil gübre uygulamaları
- Solucan gübresi üretimi

### Su Yönetimi
- Damla sulama sistemleri
- Yağmur suyu toplama
- Mulçlama teknikleri

## Modern Entegrasyon

Bu geleneksel bilgileri modern teknolojilerle destekliyoruz:
- Toprak analizi
- İklim takibi
- Verimlilik ölçümü
      `,
      category: 'Geleneksel Bilgi',
      tags: 'geleneksel,tarım,tohum,gübre,su yönetimi',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/56a19de6-ac41-4024-a521-aa5e43b5a1af.jpg',
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 3,
      title: 'Topluluk Atölyeleri ve Eğitimler',
      slug: 'topluluk-atolyeleri-egitimler',
      excerpt: 'Bilgi paylaşımı ve deneyim aktarımı odaklı topluluk etkinlikleri',
      content: `
# Topluluk Atölyeleri ve Eğitimler

Adakale Project'in en önemli bileşenlerinden biri bilgi paylaşımı ve topluluk oluşturmadır.

## Atölye Programları

### Praktik Uygulamalar
- Tohum ekimi atölyeleri
- Kompost hazırlama eğitimleri
- Doğal pestisit üretimi
- Hasat ve muhafaza teknikleri

### Sanat ve Zanaatkârlık
- Toprak saksı yapımı
- Seramik çalışmaları
- Marangozluk eğitimleri
- Doğal boyama teknikleri

### Gastronomi Atölyeleri
- Fermentasyon teknikleri
- Doğal gıda işleme
- Geleneksel tarifler
- Sağlıklı beslenme

## Topluluk Etkinlikleri

### Düzenli Buluşmalar
- Haftalık bahçe çalışmaları
- Aylık bilgi paylaşım toplantıları
- Mevsimlik hasat festivalleri

### Özel Projeler
- Tohum takas günleri
- Yerel üretici pazarları
- Çevre bilinci etkinlikleri
      `,
      category: 'Topluluk',
      tags: 'atölye,eğitim,topluluk,paylaşım,sanat',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/2a2cb953-76a5-48e7-ad0f-4a64822d82eb.jpg',
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
};

/**
 * Sample photos data
 */
export const exportPhotosData = () => {
  return [
    {
      id: 1,
      title: 'Permakültür Bahçesi',
      description: 'Çeşitli sebze ve meyvelerin birlikte yetiştiği permakültür bahçe düzenlemesi',
      category: 'Bahçecilik',
      imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/3b0f0440-151c-4006-bddb-9729103152bf.jpg',
      orderIndex: 1,
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 2,
      title: 'Kompost Üretim Alanı',
      description: 'Organik atıkların dönüştürüldüğü kompost üretim sistemimiz',
      category: 'Sürdürülebilirlik',
      imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/3ad67a1b-3181-4032-a28d-b658275eb45c.jpg',
      orderIndex: 2,
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 3,
      title: 'Sera Faaliyetleri',
      description: 'Kontrollü ortamda yetiştirilen organik sebzeler',
      category: 'Tarım',
      imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/a8c9f804-2d2d-4a8b-bb4b-205f60dbc751.jpg',
      orderIndex: 3,
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 4,
      title: 'Ata Tohumları Koleksiyonu',
      description: 'Yerel ve geleneksel tohum çeşitlerinin muhafaza edildiği koleksiyonumuz',
      category: 'Tohum Bankacılığı',
      imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/15a85938-9388-4d51-950e-4b6864c5615e.jpg',
      orderIndex: 4,
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 5,
      title: 'Topluluk Atölyesi',
      description: 'Katılımcıların birlikte çalıştığı atölye ortamı',
      category: 'Eğitim',
      imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/b19ef247-6552-4ccc-b53e-c79fc41920ea.jpg',
      orderIndex: 5,
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 6,
      title: 'Seramik Çalışmaları',
      description: 'Doğal malzemelerle yapılan seramik ve saksı üretimi',
      category: 'Sanat',
      imageUrl: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/8cd60715-56f3-4748-948f-185af5969a3b.jpg',
      orderIndex: 6,
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
};

/**
 * Sample books data
 */
export const exportBooksData = () => {
  return [
    {
      id: 1,
      title: 'Permakültür: Prensipleri ve Doğaya Yolcukları',
      author: 'Bill Mollison',
      genre: 'Sürdürülebilirlik',
      rating: 5,
      review: `
Permakültürün babası sayılan Bill Mollison'un bu klasik eseri, sürdürülebilir yaşam konusunda temel bir kaynak. Doğal sistemleri gözlemleyerek tasarım yapmak, insan ihtiyaçlarını karşılarken doğaya zarar vermeden üretim yapmak konularında çok değerli bilgiler içeriyor.

Adakale Project'te uyguladığımız birçok tekniğin teorik temellerini bu kitapta bulmak mümkün. Özellikle su yönetimi, toprak koruma ve bitkisel tasarım konularında pratik öneriler sunuyor.

Bu kitap sürdürülebilir yaşamla ilgilenen herkes için mutlaka okunması gereken bir kaynak.
      `,
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/f176359d-20a8-431d-b129-28117e8394d1.jpg',
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 2,
      title: 'Tohum Savaşları',
      author: 'Vandana Shiva',
      genre: 'Ekoloji',
      rating: 5,
      review: `
Vandana Shiva'nın bu önemli eseri, tohum üzerindeki kurumsal kontrolün ve genetiği değiştirilmiş organizmaların küresel tarım sistemi üzerindeki etkilerini ele alıyor. 

Kitap, biyoçeşitliliğin korunması ve ata tohumlarının önemini vurguluyor. Adakale Project'te uyguladığımız tohum bankacılığı çalışmalarının ne kadar kritik olduğunu anlamamı sağladı.

Özellikle yerel tohum çeşitlerinin korunması ve paylaşılması konularında çok değerli perspektifler sunuyor. Sürdürülebilir tarım yapan herkesin okuması gereken bir kitap.
      `,
      coverImage: 'https://sider.ai/autoimage/seed wars book cover',
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 3,
      title: 'Toprak: Medeniyetlerin Kaynağı',
      author: 'David R. Montgomery',
      genre: 'Tarih',
      rating: 4,
      review: `
Toprak erozyonunun tarihi boyunca medeniyetlerin yükselişi ve çöküşü üzerindeki etkisini inceleyen fascinant bir çalışma. Yazar, sürdürülebilir tarım pratiklerinin önemini tarihsel örneklerle destekliyor.

Adakale Project'te toprak koruması konusunda aldığımız önlemlerin ne kadar değerli olduğunu bu kitap sayesinde daha iyi anlıyorum. Özellikle no-till (toprağı bozmadan) tarım teknikleri konusunda çok şey öğrendim.

Tarım ve çevre konularıyla ilgilenen herkes için keyifli ve öğretici bir okuma deneyimi.
      `,
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/d73c015d-6a38-4828-9fac-29f5a63c7ebb.jpg',
      isPublished: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
};

/**
 * Site ayarları
 */
export const exportSiteSettings = () => {
  return [
    {
      settingKey: 'site_title',
      settingValue: 'Gökhan Aydınlı - Adakale Project',
      settingType: 'text'
    },
    {
      settingKey: 'site_description',
      settingValue: 'Sanat, tasarım ve sürdürülebilirlik üzerine kurgulanmış bütüncül yaşam projesi',
      settingType: 'textarea'
    },
    {
      settingKey: 'project_motto',
      settingValue: 'Bir Gayrimenkul\'den filizlenen, Birlikte büyümek, birlikte yaşamak, doğayla uyum içinde var olmak felsefesidir',
      settingType: 'textarea'
    },
    {
      settingKey: 'admin_email',
      settingValue: 'admin@adakale.com',
      settingType: 'text'
    },
    {
      settingKey: 'contact_phone',
      settingValue: '+90 XXX XXX XX XX',
      settingType: 'text'
    }
  ];
};

/**
 * Tüm verileri JSON formatında export et
 */
export const exportAllData = () => {
  const data = {
    projects: exportProjectData(),
    blogPosts: exportBlogData(),
    photos: exportPhotosData(),
    books: exportBooksData(),
    siteSettings: exportSiteSettings(),
    exportDate: new Date().toISOString(),
    version: '1.0.0'
  };
  
  return JSON.stringify(data, null, 2);
};

/**
 * Verileri dosya olarak indir
 */
export const downloadExportData = () => {
  const data = exportAllData();
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `adakale_export_${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  
  URL.revokeObjectURL(url);
};

/**
 * Görselleri listele ve indirme linklerini oluştur
 */
export const getImageUrls = () => {
  const projects = exportProjectData();
  const blogs = exportBlogData();
  const photos = exportPhotosData();
  const books = exportBooksData();
  
  const imageUrls: string[] = [];
  
  // Proje görselleri
  projects.forEach(project => {
    if (project.imageUrl) {
      imageUrls.push(project.imageUrl);
    }
  });
  
  // Blog görselleri
  blogs.forEach(blog => {
    if (blog.coverImage) {
      imageUrls.push(blog.coverImage);
    }
  });
  
  // Fotoğraf galerisi
  photos.forEach(photo => {
    if (photo.imageUrl) {
      imageUrls.push(photo.imageUrl);
    }
  });
  
  // Kitap kapakları
  books.forEach(book => {
    if (book.coverImage) {
      imageUrls.push(book.coverImage);
    }
  });
  
  return [...new Set(imageUrls)]; // Tekrarları kaldır
};