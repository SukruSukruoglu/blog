<?php
/**
 * Image migration script - Downloads images from current URLs and saves locally
 */

require_once '../config/database.php';

class ImageMigrator {
    private $conn;
    private $uploadDir = '../uploads/';
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
        
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
    }
    
    /**
     * Migrate all images from external URLs to local storage
     */
    public function migrateAllImages() {
        echo "Starting image migration...\n";
        
        $this->migrateProjectImages();
        $this->migrateBlogImages();
        $this->migratePhotoImages();
        $this->migrateBookImages();
        
        echo "Image migration completed!\n";
    }
    
    private function migrateProjectImages() {
        echo "Migrating project images...\n";
        
        $query = "SELECT id, title, image_url FROM projects WHERE image_url LIKE 'https:%'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $newPath = $this->downloadImage($row['image_url'], 'project_' . $row['id']);
            if ($newPath) {
                $this->updateProjectImage($row['id'], $newPath);
                echo "✅ Migrated: " . $row['title'] . "\n";
            }
        }
    }
    
    private function migrateBlogImages() {
        echo "Migrating blog images...\n";
        
        $query = "SELECT id, title, cover_image FROM blog_posts WHERE cover_image LIKE 'https:%'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $newPath = $this->downloadImage($row['cover_image'], 'blog_' . $row['id']);
            if ($newPath) {
                $this->updateBlogImage($row['id'], $newPath);
                echo "✅ Migrated: " . $row['title'] . "\n";
            }
        }
    }
    
    private function migratePhotoImages() {
        echo "Migrating photo gallery images...\n";
        
        $query = "SELECT id, title, image_url FROM photos WHERE image_url LIKE 'https:%'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $newPath = $this->downloadImage($row['image_url'], 'photo_' . $row['id']);
            if ($newPath) {
                $this->updatePhotoImage($row['id'], $newPath);
                echo "✅ Migrated: " . $row['title'] . "\n";
            }
        }
    }
    
    private function migrateBookImages() {
        echo "Migrating book cover images...\n";
        
        $query = "SELECT id, title, cover_image FROM books WHERE cover_image LIKE 'https:%'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $newPath = $this->downloadImage($row['cover_image'], 'book_' . $row['id']);
            if ($newPath) {
                $this->updateBookImage($row['id'], $newPath);
                echo "✅ Migrated: " . $row['title'] . "\n";
            }
        }
    }
    
    /**
     * Download image from URL and save locally
     */
    private function downloadImage($url, $prefix) {
        try {
            $imageData = file_get_contents($url);
            if ($imageData === false) {
                echo "❌ Failed to download: $url\n";
                return false;
            }
            
            // Get image info
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->buffer($imageData);
            
            // Determine file extension
            $extension = 'jpg';
            switch ($mimeType) {
                case 'image/jpeg':
                    $extension = 'jpg';
                    break;
                case 'image/png':
                    $extension = 'png';
                    break;
                case 'image/gif':
                    $extension = 'gif';
                    break;
                case 'image/webp':
                    $extension = 'webp';
                    break;
            }
            
            // Generate filename
            $filename = $prefix . '_' . uniqid() . '.' . $extension;
            $filepath = $this->uploadDir . $filename;
            
            // Save file
            if (file_put_contents($filepath, $imageData)) {
                return 'uploads/' . $filename;
            }
            
        } catch (Exception $e) {
            echo "❌ Error downloading $url: " . $e->getMessage() . "\n";
        }
        
        return false;
    }
    
    private function updateProjectImage($id, $newPath) {
        $query = "UPDATE projects SET image_url = :new_path WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':new_path', $newPath);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }
    
    private function updateBlogImage($id, $newPath) {
        $query = "UPDATE blog_posts SET cover_image = :new_path WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':new_path', $newPath);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }
    
    private function updatePhotoImage($id, $newPath) {
        $query = "UPDATE photos SET image_url = :new_path WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':new_path', $newPath);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }
    
    private function updateBookImage($id, $newPath) {
        $query = "UPDATE books SET cover_image = :new_path WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':new_path', $newPath);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }
}

// Run migration
$migrator = new ImageMigrator();
$migrator->migrateAllImages();
?>
