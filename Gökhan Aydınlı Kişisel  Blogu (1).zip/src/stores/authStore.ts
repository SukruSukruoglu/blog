/**
 * Admin authentication store - Güvenli oturum yönetimi için zustand store
 */
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  isAuthenticated: boolean;
  loginAttempts: number;
  lastAttempt: number;
  sessionExpiry: number;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  checkSession: () => boolean;
  incrementAttempts: () => void;
  resetAttempts: () => void;
}

const ADMIN_USERNAME = 'admin1981';
const ADMIN_PASSWORD = '2702';
const SESSION_DURATION = 30 * 60 * 1000; // 30 dakika
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 dakika

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      loginAttempts: 0,
      lastAttempt: 0,
      sessionExpiry: 0,

      login: (username: string, password: string) => {
        const state = get();
        
        // Brute force koruması
        if (state.loginAttempts >= MAX_ATTEMPTS) {
          const timeSinceLastAttempt = Date.now() - state.lastAttempt;
          if (timeSinceLastAttempt < LOCKOUT_DURATION) {
            return false; // Hala kilitleme süresi devam ediyor
          } else {
            // Kilitleme süresi bitti, attempt sayısını sıfırla
            set({ loginAttempts: 0 });
          }
        }

        if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
          const sessionExpiry = Date.now() + SESSION_DURATION;
          set({
            isAuthenticated: true,
            loginAttempts: 0,
            sessionExpiry,
            lastAttempt: 0
          });
          return true;
        } else {
          set({
            loginAttempts: state.loginAttempts + 1,
            lastAttempt: Date.now()
          });
          return false;
        }
      },

      logout: () => {
        set({
          isAuthenticated: false,
          sessionExpiry: 0
        });
      },

      checkSession: () => {
        const state = get();
        if (state.isAuthenticated && Date.now() > state.sessionExpiry) {
          set({ isAuthenticated: false, sessionExpiry: 0 });
          return false;
        }
        return state.isAuthenticated;
      },

      incrementAttempts: () => {
        const state = get();
        set({
          loginAttempts: state.loginAttempts + 1,
          lastAttempt: Date.now()
        });
      },

      resetAttempts: () => {
        set({ loginAttempts: 0, lastAttempt: 0 });
      }
    }),
    {
      name: 'admin-auth',
      partialize: (state) => ({
        loginAttempts: state.loginAttempts,
        lastAttempt: state.lastAttempt
      })
    }
  )
);
