-- Adakale Project Database Schema
-- MySQL version için oluşturulmuştur

CREATE DATABASE IF NOT EXISTS adakale_project CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE adakale_project;

-- Admin kullanıcıları tablosu
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL
);

-- Projeler tablosu
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    image_file VARCHAR(255),
    is_published BOOLEAN DEFAULT TRUE,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Blog yazıları tablosu
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    excerpt TEXT,
    content LONGTEXT,
    category VARCHAR(100),
    tags TEXT,
    cover_image VARCHAR(500),
    is_published BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Fotoğraflar tablosu
CREATE TABLE IF NOT EXISTS photos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    image_file VARCHAR(255),
    order_index INT DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Kitaplar tablosu
CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    genre VARCHAR(100),
    rating INT DEFAULT 5,
    review LONGTEXT,
    cover_image VARCHAR(500),
    cover_file VARCHAR(255),
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Site ayarları tablosu
CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('text', 'textarea', 'number', 'boolean', 'json') DEFAULT 'text',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Varsayılan admin kullanıcısı ekleme
INSERT INTO admin_users (username, password_hash, email) VALUES 
('admin1981', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@adakale.com');

-- Varsayılan proje verileri
INSERT INTO projects (title, description, image_url, order_index, is_published) VALUES 
('Proje Görselleri', 'Sürdürülebilir bahçecilik, permakültür uygulamaları ve doğal yaşam alanlarından görsel örnekler.', 'uploads/project1.jpg', 1, 1),
('Proje Takvimi', 'Yaklaşan atölye çalışmaları, eğitim programları ve topluluk etkinliklerinin takvimi.', 'uploads/project2.jpg', 2, 1),
('Katılımcı Görüşleri', 'Proje katılımcılarının deneyimleri, görüşleri ve sürdürülebilir yaşam hikayelerinin paylaşımı.', 'uploads/project3.jpg', 3, 1);

-- Site ayarları
INSERT INTO site_settings (setting_key, setting_value, setting_type) VALUES 
('site_title', 'Gökhan Aydınlı - Adakale Project', 'text'),
('site_description', 'Sanat, tasarım ve sürdürülebilirlik üzerine kurgulanmış bütüncül yaşam projesi', 'textarea'),
('project_motto', 'Bir Gayrimenkul\'den filizlenen, Birlikte büyümek, birlikte yaşamak, doğayla uyum içinde var olmak felsefesidir', 'textarea');
