
/**
 * Blog sayfası bileşeni - Tüm blog yazılarını listeler
 */
import { FC, useState } from 'react';
import { Link } from 'react-router';
import { Search, Tag, Clock, Filter } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';

// Blog yazısı verisi için arayüz
interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  coverImage: string;
  date: string;
  category: string;
  tags: string[];
}

const Blog: FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Örnek blog yazıları
  const blogPosts: BlogPost[] = [
    {
      id: 1,
      title: 'İstanbul\'da Gün Batımı Fotoğrafçılığı',
      excerpt: 'İstanbul\'un en güzel gün batımı manzaralarını nasıl fotoğrafladığımı ve en iyi lokasyonları anlatıyorum.',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/aca5584e-12d2-4725-84b8-566efeb12fde.jpg',
      date: '20 Haziran 2025',
      category: 'Fotoğrafçılık',
      tags: ['İstanbul', 'Gün Batımı', 'Manzara']
    },
    {
      id: 2,
      title: 'Okuduğum En İyi 5 Bilim Kurgu Kitabı',
      excerpt: 'Son zamanlarda okuduğum ve beni en çok etkileyen bilim kurgu kitaplarını inceliyorum.',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/0e5dcba5-4745-4c2a-b3c5-6d29f1269e2a.jpg',
      date: '15 Haziran 2025',
      category: 'Kitap',
      tags: ['Bilim Kurgu', 'Kitap İncelemesi', 'Öneriler']
    },
    {
      id: 3,
      title: 'Makro Fotoğrafçılık: Başlangıç Rehberi',
      excerpt: 'Makro fotoğrafçılığa başlamak isteyenler için ekipman önerileri ve temel teknikler.',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/1ba4456f-25ce-46ba-b773-b57f0f46ee9d.jpg',
      date: '10 Haziran 2025',
      category: 'Fotoğrafçılık',
      tags: ['Makro', 'Ekipman', 'Teknik']
    },
    {
      id: 4,
      title: 'Yaz İçin En İyi 10 Roman',
      excerpt: 'Yaz tatilinde okumanız için önerdiğim en iyi 10 romanı listeledim.',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/da4df0aa-f776-4adf-bdec-2609d918834c.jpg',
      date: '5 Haziran 2025',
      category: 'Kitap',
      tags: ['Roman', 'Yaz Okuma', 'Öneriler']
    },
    {
      id: 5,
      title: 'Fotoğraf Düzenlemede Işık ve Renk Yönetimi',
      excerpt: 'Fotoğraflarınızı düzenlerken ışık ve renk ayarlarını nasıl kullanabileceğinizi anlatıyorum.',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/7ac00c5a-d65d-436a-b9ea-e986dae3bae2.jpg',
      date: '1 Haziran 2025',
      category: 'Fotoğrafçılık',
      tags: ['Düzenleme', 'Işık', 'Renk']
    },
    {
      id: 6,
      title: 'Klasik Edebiyatın Başyapıtları',
      excerpt: 'Herkesin hayatında en az bir kez okuması gereken klasik edebiyat eserlerini inceliyorum.',
      coverImage: 'https://pub-cdn.sider.ai/u/U005H3WNZ28/web-coder/685a2ff7dc08f40c094c5af3/resource/5c6393bd-9b6c-4bef-997c-d62e56f8529f.jpg',
      date: '25 Mayıs 2025',
      category: 'Kitap',
      tags: ['Klasikler', 'Edebiyat', 'Başyapıtlar']
    }
  ];

  // Kategorileri dinamik olarak oluştur
  const categories = Array.from(new Set(blogPosts.map(post => post.category)));

  // Filtrelenmiş yazılar
  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory ? post.category === selectedCategory : true;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-merriweather">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">Blog Yazıları</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Fotoğrafçılık, kitaplar ve diğer konulardaki düşüncelerimi ve deneyimlerimi paylaştığım yazılar.
          </p>
        </div>
      </div>

      {/* Filtreler */}
      <div className="bg-white dark:bg-slate-900 shadow-md py-4 px-6 sticky top-16 z-30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Blog yazılarında ara..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2 overflow-x-auto pb-2 w-full md:w-auto">
            <Filter className="text-slate-500 h-4 w-4 flex-shrink-0" />
            <Button 
              variant={selectedCategory === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(null)}
              className="flex-shrink-0"
            >
              Tümü
            </Button>
            
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="flex-shrink-0"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Blog yazıları */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          {filteredPosts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map(post => (
                <Link to={`/blog/${post.id}`} key={post.id} className="group">
                  <article className="bg-white dark:bg-slate-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow h-full flex flex-col">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={post.coverImage} 
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 right-3 bg-blue-600 text-white text-xs font-medium px-2.5 py-1 rounded">
                        {post.category}
                      </div>
                    </div>
                    
                    <div className="p-6 flex-grow flex flex-col">
                      <div className="flex items-center text-sm text-slate-500 dark:text-slate-400 mb-2">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{post.date}</span>
                      </div>
                      
                      <h2 className="text-xl font-bold mb-3 text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        {post.title}
                      </h2>
                      
                      <p className="text-slate-600 dark:text-slate-300 mb-4 flex-grow">
                        {post.excerpt}
                      </p>
                      
                      <div className="flex flex-wrap gap-2 mt-auto">
                        {post.tags.map(tag => (
                          <div key={tag} className="flex items-center text-xs bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 px-2.5 py-1 rounded">
                            <Tag className="h-3 w-3 mr-1" />
                            {tag}
                          </div>
                        ))}
                      </div>
                    </div>
                  </article>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <h3 className="text-2xl font-medium text-slate-800 dark:text-slate-200 mb-2">
                Sonuç bulunamadı
              </h3>
              <p className="text-slate-600 dark:text-slate-400">
                Arama kriterlerinize uygun yazı bulunamadı. Lütfen farklı bir arama terimi deneyin.
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Blog;
