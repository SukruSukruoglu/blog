<?php
/**
 * URL listesinden görselleri toplu indirme scripti
 */

class ImageDownloader {
    private $downloadDir;
    private $baseUrl;
    
    public function __construct($downloadDir = '../uploads/', $baseUrl = '') {
        $this->downloadDir = $downloadDir;
        $this->baseUrl = $baseUrl;
        
        if (!is_dir($this->downloadDir)) {
            mkdir($this->downloadDir, 0777, true);
        }
    }
    
    /**
     * URL listesinden görselleri indir
     */
    public function downloadFromUrls($urls) {
        echo "🖼️ Görsel indirme başlıyor...\n";
        echo "Toplam " . count($urls) . " görsel indirilecek.\n\n";
        
        $successCount = 0;
        $failCount = 0;
        
        foreach ($urls as $index => $url) {
            echo "(" . ($index + 1) . "/" . count($urls) . ") İndiriliyor: " . basename($url) . "\n";
            
            if ($this->downloadImage($url)) {
                $successCount++;
                echo "  ✅ Başarılı\n";
            } else {
                $failCount++;
                echo "  ❌ Başarısız\n";
            }
        }
        
        echo "\n📊 İndirme tamamlandı!\n";
        echo "✅ Başarılı: $successCount\n";
        echo "❌ Başarısız: $failCount\n";
    }
    
    /**
     * Tekil görsel indirme
     */
    private function downloadImage($url) {
        try {
            // URL'den görsel verilerini al
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
            
            $imageData = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode !== 200 || !$imageData) {
                return false;
            }
            
            // Dosya adı oluştur
            $pathInfo = pathinfo($url);
            $extension = isset($pathInfo['extension']) ? $pathInfo['extension'] : 'jpg';
            $filename = $this->generateFilename($url, $extension);
            $filepath = $this->downloadDir . $filename;
            
            // Dosyayı kaydet
            if (file_put_contents($filepath, $imageData)) {
                return $filename;
            }
            
        } catch (Exception $e) {
            echo "  ⚠️ Hata: " . $e->getMessage() . "\n";
        }
        
        return false;
    }
    
    /**
     * Benzersiz dosya adı oluştur
     */
    private function generateFilename($url, $extension) {
        // URL'den anlamlı bir isim çıkarmaya çalış
        $pathInfo = pathinfo($url);
        $basename = isset($pathInfo['filename']) ? $pathInfo['filename'] : '';
        
        // Sider.ai autoimage linklerini tespit et
        if (strpos($url, 'sider.ai/autoimage/') !== false) {
            $parts = explode('autoimage/', $url);
            if (isset($parts[1])) {
                $basename = str_replace([' ', '+', '%20'], '_', $parts[1]);
            }
        }
        
        // Özel karakterleri temizle
        $basename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $basename);
        
        // Boşsa varsayılan isim ver
        if (empty($basename)) {
            $basename = 'image_' . uniqid();
        }
        
        // Benzersizlik için timestamp ekle
        $filename = $basename . '_' . time() . '.' . $extension;
        
        // Dosya zaten varsa sayı ekle
        $counter = 1;
        $originalFilename = $filename;
        while (file_exists($this->downloadDir . $filename)) {
            $filename = pathinfo($originalFilename, PATHINFO_FILENAME) . '_' . $counter . '.' . $extension;
            $counter++;
        }
        
        return $filename;
    }
    
    /**
     * URL listesini dosyadan oku
     */
    public function downloadFromFile($filePath) {
        if (!file_exists($filePath)) {
            die("URL dosyası bulunamadı: $filePath\n");
        }
        
        $content = file_get_contents($filePath);
        $urls = array_filter(array_map('trim', explode("\n", $content)));
        
        $this->downloadFromUrls($urls);
    }
}

// Komut satırından kullanım
if ($argc < 2) {
    echo "Kullanım:\n";
    echo "  php download_images.php <url_listesi_dosyası>\n";
    echo "  php download_images.php image_urls.txt\n\n";
    echo "URL dosyası formatı:\n";
    echo "  Her satırda bir URL olmalı\n";
    exit(1);
}

$urlFile = $argv[1];
$downloader = new ImageDownloader();
$downloader->downloadFromFile($urlFile);
?>